# 🐾 PetWorld — Tienda de Mascotas (HTML/CSS/JS)

Sitio web estático de PetWorld con carrito funcional, buscador y carrusel. Funciona con **doble clic** — no necesita servidor ni Python.

## 📁 Estructura

```
PetWorldWeb/
├── index.html        ← Página principal (hero, categorías, novedades)
├── perros.html       ← Catálogo exclusivo de perros (5 productos)
├── gatos.html        ← Catálogo exclusivo de gatos (5 productos)
├── coleccion.html    ← Colección completa (10 productos)
├── carrito.html      ← Carrito de compras con checkout
├── styles.css        ← Estilos de la página principal
├── coleccion.css     ← Estilos compartidos de catálogos
├── script.js         ← JS compartido (carrito, buscador, carrusel)
└── README.md
```

## 🚀 Cómo usarlo

### Opción 1 — Doble clic (la más simple)
1. Descomprime el ZIP
2. Haz doble clic en `index.html`
3. Se abre en tu navegador y todo funciona

### Opción 2 — Servidor local (recomendado)
Si quieres que las URLs se vean más limpias:
```bash
cd PetWorldWeb
python -m http.server 8000
# Abre: http://localhost:8000
```

## ✨ Funcionalidades

### Navegación
- ✅ Menú superior con enlaces entre páginas
- ✅ Logo click → vuelve al inicio
- ✅ Breadcrumbs (Inicio > Catálogo > Perros)
- ✅ Botones de categorías clickables

### Carrusel automático (solo index)
- ✅ 3 slides que cambian cada 5 segundos
- ✅ Flechas manuales (← →)
- ✅ Puntos (dots) clickables

### Carrito de compras (localStorage)
- ✅ Click en "+ Carrito" agrega productos
- ✅ Badge en el icono del carrito se actualiza
- ✅ Click en el icono del carrito → abre `carrito.html`
- ✅ Cambiar cantidad (+/−) y eliminar items
- ✅ Cálculo automático de subtotal, envío y total
- ✅ Envío gratis desde $100
- ✅ Botón "Proceder al Pago" simula checkout
- ✅ **Persistente**: sobrevive cerrar el navegador

### Buscador
- ✅ Escribe en el buscador y presiona Enter
- ✅ Filtra productos de la página actual
- ✅ Si no hay coincidencias, muestra mensaje

### Imágenes con fallback
- ✅ Las imágenes se cargan de Unsplash (requiere internet)
- ✅ **Si no hay internet o fallan**, se muestran emojis automáticamente (🎾 🪴 🪶 etc.)

### Toast notificaciones
- ✅ Mensajes flotantes al agregar productos, hacer checkout, etc.

## 🎨 Paleta de colores

- Verde menta: `#2b7a78` (color primario)
- Verde claro: `#dbeee9` (fondo)
- Verde agua: `#4ed6c1` (logo)
- Negro: `#111` (botones principales)

## 🛠️ Personalización

### Agregar productos
Edita el HTML de `perros.html` o `gatos.html` y copia el bloque de un producto:
```html
<div class="product-card" data-category="juguetes">
  <div class="img-wrapper">
    <img src="URL_DE_IMAGEN" alt="Nombre producto" data-emoji="🎾">
  </div>
  <h4>Nombre del producto</h4>
  <p class="price">$99.99</p>
  <button class="btn-detail">Ver Detalle</button>
  <button class="btn-add-cart" onclick="addToCart('Nombre del producto', 99.99, '🎾')">+ Carrito</button>
</div>
```

### Cambiar imágenes
Las imágenes son URLs de Unsplash. Puedes cambiarlas por:
- Otras URLs de Unsplash
- Imágenes locales (ej: `images/mi-foto.jpg` — crea carpeta `images/`)
- Emojis: elimina el `<img>` y deja el emoji directamente

### Cambiar info del footer
Edita el `<footer>` en cada HTML.

## 👥 Equipo
- Daniel Campos Sotelo
- Diony María Esparza Cruz
- Kevin Alejandro Flores Acosta
- Alan Josué García Casas

**Materia:** Negocios Electrónicos 1
**Institución:** Instituto Tecnológico de Aguascalientes — TecNM
**Fecha:** noviembre 2026
