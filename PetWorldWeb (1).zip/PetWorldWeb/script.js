// ============================================================
//  PetWorld — JavaScript compartido
//  Funcionalidades: carrito (localStorage), buscador, carrusel,
//  navegación, toast notificaciones, fallback de imágenes
// ============================================================

// ---------- Utilidades ----------
function $(sel, ctx = document) { return ctx.querySelector(sel); }
function $$(sel, ctx = document) { return Array.from(ctx.querySelectorAll(sel)); }
function getCart() {
    try { return JSON.parse(localStorage.getItem("petworld_cart")) || []; }
    catch { return []; }
}
function saveCart(cart) {
    localStorage.setItem("petworld_cart", JSON.stringify(cart));
    updateCartBadge();
}
function cartCount() { return getCart().reduce((s, i) => s + i.qty, 0); }
function cartTotal() { return getCart().reduce((s, i) => s + i.price * i.qty, 0); }

// ---------- Carrito ----------
function addToCart(nombre, precio, emoji = "🛒") {
    const cart = getCart();
    const precioNum = Number(precio) || 0;
    const existing = cart.find(i => i.nombre === nombre);
    if (existing) {
        existing.qty += 1;
        existing.price = precioNum; // normalizar
    } else {
        cart.push({ nombre, price: precioNum, emoji, qty: 1 });
    }
    saveCart(cart);
    showToast(`✓ "${nombre}" agregado al carrito`);
}

function removeFromCart(idx) {
    const cart = getCart();
    cart.splice(idx, 1);
    saveCart(cart);
}

function clearCart() {
    localStorage.removeItem("petworld_cart");
    updateCartBadge();
}

function updateCartBadge() {
    const n = cartCount();
    $$(".badge").forEach(el => {
        el.textContent = n;
        el.classList.toggle("show", n > 0);
    });
}

// ---------- Toast ----------
function showToast(msg) {
    let toast = $("#toast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "toast";
        toast.className = "toast";
        toast.innerHTML = '<i class="fa-solid fa-check-circle"></i><span></span>';
        document.body.appendChild(toast);
    }
    toast.querySelector("span").textContent = msg;
    toast.classList.add("show");
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
}

// ---------- Fallback de imágenes (emoji si la imagen no carga) ----------
function setupImageFallback() {
    $$("img").forEach(img => {
        img.addEventListener("error", () => {
            const wrapper = img.closest(".img-wrapper, .mini-card, .promo-banner-content, .category-card");
            if (wrapper && !wrapper.querySelector(".img-fallback")) {
                const fb = document.createElement("div");
                fb.className = "img-fallback";
                fb.textContent = img.dataset.emoji || "🐾";
                wrapper.classList.add("no-img");
                wrapper.appendChild(fb);
            }
            img.style.display = "none";
        });
    });
}

// ---------- Buscador ----------
function setupSearch() {
    const input = $("#search-input, .search-bar input");
    if (!input) return;
    input.addEventListener("keypress", (e) => {
        if (e.key === "Enter" && e.target.value.trim()) {
            const q = e.target.value.trim().toLowerCase();
            // Buscar en la página actual productos que coincidan
            const cards = $$(".product-card");
            let found = 0;
            cards.forEach(card => {
                const name = (card.querySelector("h4")?.textContent || "").toLowerCase();
                const match = name.includes(q);
                card.style.display = match ? "" : "none";
                if (match) found++;
            });
            if (found === 0 && cards.length > 0) {
                showToast("No se encontraron productos con: " + q);
            } else {
                showToast(`✓ ${found} producto(s) encontrado(s)`);
            }
            // Si no estamos en una página de catálogo, redirigir
            if (cards.length === 0) {
                window.location.href = "coleccion.html?q=" + encodeURIComponent(q);
            }
        }
    });
}

// ---------- Carrusel (solo página index) ----------
function setupCarousel() {
    const banner = $(".hero-banner");
    if (!banner) return;
    const slides = [
        { title: "¡Novedades en Accesorios!", text: "Encuentra lo mejor para tus mascotas", btn: "Ver Colección", link: "coleccion.html" },
        { title: "20% de DESCUENTO", text: "En todas las correas este mes", btn: "Comprar ahora", link: "perros.html" },
        { title: "Llega tu nuevo amigo", text: "Adopción responsable con PetWorld", btn: "Saber más", link: "#" }
    ];
    let current = 0;
    const dots = $$(".dot");
    const content = $(".hero-content");
    const prev = $(".carousel-arrow.prev");
    const next = $(".carousel-arrow.next");
    if (!content || !prev || !next) return;

    function go(i) {
        current = (i + slides.length) % slides.length;
        const s = slides[current];
        content.innerHTML = `
            <h2>${s.title}</h2>
            <p>${s.text}</p>
            <a href="${s.link}" class="btn btn-black">${s.btn}</a>`;
        dots.forEach((d, idx) => d.classList.toggle("active", idx === current));
    }

    prev.addEventListener("click", () => go(current - 1));
    next.addEventListener("click", () => go(current + 1));
    dots.forEach((d, idx) => d.addEventListener("click", () => go(idx)));

    // Auto-play cada 5 segundos
    setInterval(() => go(current + 1), 5000);
}

// ---------- Filtros catálogo (básico: toggle activo) ----------
function setupFilters() {
    $$(".category-list li").forEach(li => {
        li.addEventListener("click", (e) => {
            e.preventDefault();
            $$(".category-list li").forEach(x => x.classList.remove("active"));
            li.classList.add("active");
            // Filtrado simple: ocultar/mostrar productos por sub-categoría
            const filter = li.querySelector("a")?.textContent.trim().toLowerCase();
            const cards = $$(".product-card:not(.empty-card)");
            if (filter === "todos") {
                cards.forEach(c => c.style.display = "");
                return;
            }
            cards.forEach(c => {
                const tags = (c.dataset.category || "").toLowerCase();
                c.style.display = tags.includes(filter) ? "" : "none";
            });
        });
    });
}

// ---------- Botones "Ver Detalle" ----------
function setupProductButtons() {
    $$(".btn-detail").forEach(btn => {
        btn.addEventListener("click", () => {
            const card = btn.closest(".product-card");
            const name = card?.querySelector("h4")?.textContent || "Producto";
            const price = card?.querySelector(".price")?.textContent || "$0";
            const emoji = card?.querySelector("img")?.dataset.emoji || "🐾";
            // Como no hay página de detalle, mostramos info
            showToast(`📋 ${name} — ${price}`);
        });
    });
}

// ---------- Click en "Mi Perfil" ----------
function setupProfile() {
    $$(".action-item").forEach(item => {
        if (item.textContent.includes("Mi Perfil")) {
            item.addEventListener("click", () => {
                showToast("👤 Inicia sesión para ver tu perfil (demo)");
            });
        } else if (item.textContent.includes("Carrito")) {
            item.addEventListener("click", () => {
                const cart = getCart();
                if (cart.length === 0) {
                    showToast("🛒 Tu carrito está vacío");
                } else {
                    const total = cartTotal();
                    showToast(`🛒 ${cartCount()} artículo(s) — Total: $${total.toFixed(2)}`);
                }
            });
        }
    });
}

// ---------- Inicialización ----------
document.addEventListener("DOMContentLoaded", () => {
    updateCartBadge();
    setupImageFallback();
    setupSearch();
    setupCarousel();
    setupFilters();
    setupProductButtons();
    setupProfile();
});
