<?php
/**
 * config.php — Configuración central del proyecto PetWorld
 * Incluye: credenciales BD, PayPal, SMTP para correo, constantes.
 * Cárgalo con: require_once __DIR__ . '/config.php';
 */

// ============================ Base de datos ============================
$DB_HOST     = '127.0.0.1';
$DB_PUERTO   = '3306';
$DB_NAME     = 'petworld';
$DB_USER     = 'root';
$DB_PASSWORD = '';

// ============================ PayPal API ============================
// 1) Crea cuenta en https://developer.paypal.com → My Apps & Credentials
// 2) Copia tu Client ID (sandbox para pruebas, live para producción)
// 3) En sandbox también genera un Secret para los endpoints backend
define('PAYPAL_CLIENT_ID',     'AUtzQcKx2gYBrEGjL8yJpKxYOUR_CLIENT_ID_HERE');
define('PAYPAL_CLIENT_SECRET', 'EGXXXXXXXXXXXXXXXXXXXXXXXX_SECRET_HERE');
define('PAYPAL_MODE',          'sandbox');   // 'sandbox' o 'live'
define('PAYPAL_CURRENCY',      'MXN');

// URL base de la API REST de PayPal
define('PAYPAL_API_BASE',
    PAYPAL_MODE === 'live'
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com'
);

// ============================ Correo (SMTP) ============================
// Para desarrollo local con XAMPP puedes usar la función mail() de PHP.
// Para enviar correos reales, configura SMTP con una cuenta de Gmail/App Password.
define('SMTP_HOST',     'smtp.gmail.com');
define('SMTP_USER',     'tu_correo@gmail.com');
define('SMTP_PASSWORD', 'tu_app_password_de_16_caracteres');  // https://myaccount.google.com/apppasswords
define('SMTP_PORT',     587);
define('SMTP_FROM',     'no-reply@petworld.mx');
define('SMTP_FROM_NAME','Tienda PetWorld');
define('SMTP_USAR_PHPMAILER', false);  // false = usar mail() nativo; true = PHPMailer+SMTP

// ============================ Tienda ============================
define('NOMBRE_TIENDA',  'PetWorld');
define('TIENDA_URL',     'http://localhost/PetWorld');   // sin barra final
define('MONEDA',         'MXN');
define('SIMBOLO_MONEDA', '$');
define('ENVIO_COSTO',    99);     // costo de envío base
define('ENVIO_GRATIS_DESDE', 599); // envío gratis a partir de este monto

// Datos bancarios para pago por Transferencia
define('BANCO_NOMBRE',   'Banco PetWorld');
define('BANCO_CLABE',    '012 345 6789 0123 4567');
define('BANCO_TITULAR',  'PetWorld S.A. de C.V.');
define('BANCO_REFERENCIA_PREFIJO', 'PW');

// ============================ Sesion / seguridad ============================
// session_name corto para no chocar con otros proyectos en localhost
if (session_status() === PHP_SESSION_NONE) {
    session_name('PETWORLD_SID');
    session_start();
}

// Genera / recupera un session_id estable para favoritos de invitados
if (empty($_SESSION['guest_sid'])) {
    $_SESSION['guest_sid'] = bin2hex(random_bytes(16));
}
define('GUEST_SID', $_SESSION['guest_sid']);
