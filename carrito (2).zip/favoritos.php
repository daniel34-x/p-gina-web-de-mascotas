<?php
/** favoritos.php · Lista de deseos (sin login, por sesión) */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$productos = fav_products();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Favoritos · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">♥ Mis Favoritos</div>
    <div class="breadcrumb"><a href="index.php">Inicio</a><span class="sep">/</span><span class="here">Favoritos</span></div>
  </div>
</div>

<div class="container" style="padding:30px 20px;">
  <?php if (!empty($productos)): ?>
    <p class="section-sub"><?= count($productos) ?> producto(s) en tu lista de deseos</p>
    <div class="product-grid">
      <?php foreach ($productos as $p) echo producto_card_html($p); ?>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <div class="ic">♥</div>
      <h3>Tu lista de deseos está vacía</h3>
      <p>Pulsa el corazón en cualquier producto para guardarlo aquí.</p>
      <a href="catalogo.php" class="btn btn-primary" style="margin-top:18px;">Explorar catálogo →</a>
    </div>
  <?php endif; ?>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
