<?php
/** carrito.php · Vista 04 — Carrito con sesión PHP */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
cart_init();

// Acciones
if (isset($_GET['action'])) {
    $a = $_GET['action'];
    if ($a === 'add' && isset($_POST['producto_id'])) {
        cart_add((int)$_POST['producto_id'], (int)($_POST['qty'] ?? 1));
        header('Location: carrito.php'); exit;
    }
    if ($a === 'remove' && isset($_GET['id'])) { cart_remove((int)$_GET['id']); header('Location: carrito.php'); exit; }
    if ($a === 'clear') { cart_clear(); header('Location: carrito.php'); exit; }
}

$items   = cart_items();
$subtotal= cart_subtotal();
$envio   = ($subtotal >= ENVIO_GRATIS_DESDE || $subtotal == 0) ? 0 : ENVIO_COSTO;
$total   = $subtotal + $envio;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Carrito · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">🛒 Carrito de Compras</div>
    <div class="breadcrumb"><a href="index.php">Inicio</a><span class="sep">/</span><span class="here">Carrito</span></div>
  </div>
</div>

<div class="cart-layout">
  <div class="cart-items">
    <h2>
      <span>Artículos (<?= cart_count() ?>)</span>
      <?php if (!empty($items)): ?>
        <a href="carrito.php?action=clear" class="btn btn-ghost btn-sm" style="color:var(--pw-red);">Vaciar</a>
      <?php endif; ?>
    </h2>

    <?php if (!empty($items)): foreach ($items as $it):
        $cant = $_SESSION['carrito'][$it['id']] ?? 1;
        $sub  = $it['precio'] * $cant;
    ?>
      <div class="cart-row">
        <div class="emoji-box"><?= htmlspecialchars($it['imagen']) ?></div>
        <div class="info">
          <a href="detalle.php?id=<?= (int)$it['id'] ?>"><b><?= htmlspecialchars($it['nombre']) ?></b></a>
          <small><?= htmlspecialchars($it['marca'] ?? '') ?> · <?= htmlspecialchars($it['catLabel']) ?></small>
        </div>
        <div class="price"><?= money($it['precio']) ?></div>
        <div class="price">× <?= (int)$cant ?></div>
        <div class="subtotal"><?= money($sub) ?>
          <div><a href="carrito.php?action=remove&id=<?= (int)$it['id'] ?>" class="remove-btn" title="Eliminar">✕</a></div>
        </div>
      </div>
    <?php endforeach; else: ?>
      <div class="cart-empty">
        <div class="ic">🛒</div>
        <h3>Tu carrito está vacío</h3>
        <p style="margin-top:6px;">Agrega productos para tu mascota.</p>
        <a href="catalogo.php" class="btn btn-primary" style="margin-top:18px;">Ver catálogo →</a>
      </div>
    <?php endif; ?>
  </div>

  <?php if (!empty($items)): ?>
  <div class="cart-summary">
    <h2>📋 Resumen</h2>
    <div class="summary-row"><span>Subtotal</span><b><?= money($subtotal) ?></b></div>
    <div class="summary-row"><span>Envío</span><b><?= $envio === 0 ? '<span style="color:var(--pw-mint-dark)">Gratis</span>' : money($envio) ?></b></div>
    <?php if ($subtotal < ENVIO_GRATIS_DESDE && $subtotal > 0): ?>
      <div class="ship-note">🚚 Te faltan <b><?= money(ENVIO_GRATIS_DESDE - $subtotal) ?></b> para envío gratis</div>
    <?php else: ?>
      <div class="ship-note">🚚 ¡Envío gratis aplicado!</div>
    <?php endif; ?>
    <div class="summary-total"><span>Total</span><span class="v"><?= money($total) ?></span></div>
    <a href="checkout.php" class="btn btn-primary btn-block btn-lg" style="margin-top:14px;">Proceder al pago →</a>
    <a href="catalogo.php" class="btn btn-ghost btn-block" style="margin-top:10px;">Seguir comprando</a>
  </div>
  <?php endif; ?>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
