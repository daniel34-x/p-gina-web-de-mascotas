<?php
/** pedidos_ok.php · Página de confirmación con código de seguimiento */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$codigo = isset($_GET['codigo']) ? trim($_GET['codigo']) : '';
$pedido = null; $items = [];
if ($codigo !== '') {
    $stmt = $conexion->prepare("SELECT * FROM pedidos WHERE codigo_seguimiento = ? LIMIT 1");
    $stmt->execute([$codigo]);
    $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($pedido) {
        $stmtI = $conexion->prepare("SELECT * FROM pedido_items WHERE pedido_id = ?");
        $stmtI->execute([$pedido['id']]);
        $items = $stmtI->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>¡Pedido confirmado! · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="container" style="padding:60px 20px;max-width:760px;margin:auto;">
  <?php if ($pedido): ?>
    <div style="text-align:center;margin-bottom:30px;">
      <div style="font-size:72px;">✅</div>
      <h1 class="section-title">¡Gracias por tu compra!</h1>
      <p style="color:var(--pw-gray);font-size:16px;">Hemos enviado la confirmación a <b><?= htmlspecialchars($pedido['cliente_email']) ?></b></p>
    </div>

    <div class="cart-summary" style="margin-bottom:20px;">
      <div style="text-align:center;background:var(--pw-mint-soft);color:var(--pw-mint-dark);padding:18px;border-radius:8px;">
        <div style="font-size:13px;text-transform:uppercase;letter-spacing:1px;">Tu código de seguimiento</div>
        <div style="font-size:26px;font-weight:800;font-family:'Poppins',sans-serif;margin-top:4px;"><?= htmlspecialchars($pedido['codigo_seguimiento']) ?></div>
        <div style="font-size:13px;margin-top:6px;">Estado: <b><?= htmlspecialchars($pedido['estado_envio']) ?></b></div>
      </div>

      <h2 style="font-family:'Poppins',sans-serif;font-size:16px;margin:18px 0 12px;">Detalle del pedido</h2>
      <table class="table">
        <thead><tr><th>Producto</th><th style="text-align:center;">Cant.</th><th style="text-align:right;">Subtotal</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td><?= htmlspecialchars($it['nombre']) ?></td>
              <td style="text-align:center;"><?= (int)$it['cantidad'] ?></td>
              <td style="text-align:right;"><?= money($it['precio'] * $it['cantidad']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="summary-total"><span>Total pagado</span><span class="v"><?= money($pedido['total']) ?></span></div>

      <?php if ($pedido['metodo_pago'] === 'Transferencia'): ?>
        <div class="banco-box" style="margin-top:14px;">
          <b>🏦 Para completar tu pago por transferencia:</b><br>
          Banco: <?= BANCO_NOMBRE ?><br>
          CLABE: <b><?= BANCO_CLABE ?></b><br>
          Titular: <?= BANCO_TITULAR ?><br>
          Referencia: <b><?= htmlspecialchars($pedido['codigo_seguimiento']) ?></b><br>
          <small>Envía tu comprobante a <?= SMTP_FROM ?> para confirmar el pago.</small>
        </div>
      <?php endif; ?>

      <a href="seguimiento.php?codigo=<?= urlencode($pedido['codigo_seguimiento']) ?>" class="btn btn-mint btn-block" style="margin-top:14px;">📦 Rastrear mi envío</a>
      <a href="catalogo.php" class="btn btn-ghost btn-block" style="margin-top:10px;">Seguir comprando</a>
    </div>
  <?php else: ?>
    <div class="empty-state">
      <div class="ic">🤔</div>
      <h3>No se encontró el pedido</h3>
      <p>El código no es válido o el pedido no existe.</p>
      <a href="index.php" class="btn btn-primary" style="margin-top:14px;">Volver al inicio</a>
    </div>
  <?php endif; ?>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
