<?php
/** index.php · Vista 01 — INICIO rediseñado */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

try {
    $categorias = $conexion->query("SELECT c.*, COUNT(p.id) AS total
        FROM categorias c LEFT JOIN productos p ON c.id = p.categoria_id
        GROUP BY c.id ORDER BY c.nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
    $destacados = $conexion->query("SELECT p.*, c.nombre AS catLabel, c.color AS catColor
        FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id
        WHERE p.destacado = 1 ORDER BY p.id ASC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $categorias = []; $destacados = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PetWorld · Tienda de Mascotas en Línea</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar('index'); ?>

<section class="hero">
  <div class="container hero-content">
    <h1>Todo para tu mejor amigo 🐾</h1>
    <p>Alimento premium, juguetes, accesorios y más para perros, gatos, aves, roedores y peces. Envío gratis desde $599.</p>
    <a href="catalogo.php" class="btn btn-primary btn-lg">Ver Catálogo →</a>
  </div>
</section>

<section class="container">
  <h2 class="section-title">Compra por <span class="accent">categoría</span></h2>
  <p class="section-sub">Encuentra justo lo que tu mascota necesita</p>
  <div class="cat-grid">
    <?php foreach ($categorias as $c): ?>
      <a href="catalogo.php?cat=<?= (int)$c['id'] ?>" class="cat-card">
        <span class="cat-emoji"><?= htmlspecialchars($c['icono']) ?></span>
        <h3><?= htmlspecialchars($c['nombre']) ?></h3>
        <div class="cat-count"><?= (int)$c['total'] ?> productos</div>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="container">
  <h2 class="section-title">Productos <span class="accent">destacados</span></h2>
  <p class="section-sub">Los favoritos de nuestros clientes</p>
  <div class="product-grid">
    <?php if (!empty($destacados)): foreach ($destacados as $p) echo producto_card_html($p); ?>
    <?php else: ?>
      <div class="empty-state">
        <div class="ic">📦</div>
        <h3>Aún no hay productos</h3>
        <p>Importa <code>database/petworld.sql</code> en phpMyAdmin para empezar.</p>
      </div>
    <?php endif; ?>
  </div>
  <div style="text-align:center;margin-top:30px;">
    <a href="catalogo.php" class="btn btn-ghost btn-lg">Ver todos los productos →</a>
  </div>
</section>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
