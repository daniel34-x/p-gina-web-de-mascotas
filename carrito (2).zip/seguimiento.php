<?php
/** seguimiento.php · Rastrea pedido por código o email */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$codigo = isset($_GET['codigo']) ? trim($_GET['codigo']) : (isset($_POST['codigo']) ? trim($_POST['codigo']) : '');
$pedido = null; $items = [];
if ($codigo !== '') {
    $stmt = $conexion->prepare("SELECT * FROM pedidos WHERE codigo_seguimiento = ? LIMIT 1");
    $stmt->execute([$codigo]);
    $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($pedido) {
        $stmtI = $conexion->prepare("SELECT * FROM pedido_items WHERE pedido_id = ?");
        $stmtI->execute([$pedido['id']]);
        $items = $stmtI->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Seguimiento de pedido · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">📦 Rastrear mi pedido</div>
    <div class="breadcrumb"><a href="index.php">Inicio</a><span class="sep">/</span><span class="here">Seguimiento</span></div>
  </div>
</div>

<div class="container" style="padding:40px 20px;max-width:760px;margin:auto;">
  <form method="POST" action="seguimiento.php" style="display:flex;gap:10px;margin-bottom:24px;">
    <input type="text" name="codigo" placeholder="Ej: PW-2026-A1B2" value="<?= htmlspecialchars($codigo) ?>"
           style="flex:1;padding:14px;border:1.5px solid var(--pw-line);border-radius:8px;font-size:15px;">
    <button type="submit" class="btn btn-primary btn-lg">Rastrear →</button>
  </form>

  <?php if ($codigo !== '' && !$pedido): ?>
    <div class="alert alert-err">✗ No se encontró ningún pedido con el código <b><?= htmlspecialchars($codigo) ?></b>.</div>
  <?php elseif ($pedido): ?>
    <div class="cart-summary">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <div>
          <div style="font-size:12px;color:var(--pw-gray);text-transform:uppercase;">Código</div>
          <div style="font-size:22px;font-weight:800;color:var(--pw-orange);font-family:'Poppins',sans-serif;"><?= htmlspecialchars($pedido['codigo_seguimiento']) ?></div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:12px;color:var(--pw-gray);text-transform:uppercase;">Estado del envío</div>
          <?php
            $estPill = ['Procesando'=>'pill-yellow','En tránsito'=>'pill-blue','Entregado'=>'pill-green','Cancelado'=>'pill-red'];
            $cls = $estPill[$pedido['estado_envio']] ?? 'pill-yellow';
          ?>
          <span class="pill <?= $cls ?>"><?= htmlspecialchars($pedido['estado_envio']) ?></span>
        </div>
      </div>

      <!-- Timeline visual -->
      <div style="display:flex;justify-content:space-between;margin:24px 0;position:relative;">
        <?php
          $pasos = ['Procesando','En tránsito','Entregado'];
          $idx = array_search($pedido['estado_envio'], $pasos);
          if ($idx === false) $idx = -1;
          foreach ($pasos as $i => $paso):
            $done = $i <= $idx;
        ?>
          <div style="flex:1;text-align:center;position:relative;">
            <div style="width:36px;height:36px;border-radius:50%;margin:0 auto 8px;
                 background:<?= $done ? 'var(--pw-mint)' : 'var(--pw-gray-light)' ?>;
                 color:<?= $done ? '#fff' : 'var(--pw-gray)' ?>;
                 display:flex;align-items:center;justify-content:center;font-weight:700;">
              <?= $done ? '✓' : ($i+1) ?>
            </div>
            <div style="font-size:12px;color:<?= $done ? 'var(--pw-ink)' : 'var(--pw-gray)' ?>;font-weight:<?= $done ? '600' : '400' ?>"><?= $paso ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="summary-row"><span>Fecha</span><b><?= date('d/m/Y H:i', strtotime($pedido['fecha'])) ?></b></div>
      <div class="summary-row"><span>Cliente</span><b><?= htmlspecialchars($pedido['cliente_nombre']) ?></b></div>
      <div class="summary-row"><span>Dirección</span><b style="text-align:right;"><?= htmlspecialchars($pedido['direccion_envio']) ?></b></div>
      <div class="summary-row"><span>Método de pago</span><b><?= htmlspecialchars($pedido['metodo_pago']) ?></b></div>
      <div class="summary-row"><span>Estado del pago</span><b><?= htmlspecialchars($pedido['estado_pago']) ?></b></div>

      <h2 style="font-family:'Poppins',sans-serif;font-size:15px;margin:18px 0 10px;">Productos</h2>
      <table class="table">
        <thead><tr><th>Producto</th><th style="text-align:center;">Cant.</th><th style="text-align:right;">Subtotal</th></tr></thead>
        <tbody>
          <?php foreach ($items as $it): ?>
            <tr><td><?= htmlspecialchars($it['nombre']) ?></td><td style="text-align:center;"><?= (int)$it['cantidad'] ?></td><td style="text-align:right;"><?= money($it['precio']*$it['cantidad']) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="summary-total"><span>Total</span><span class="v"><?= money($pedido['total']) ?></span></div>
    </div>
  <?php else: ?>
    <div class="alert alert-info">💡 Ingresa el código que te llegó por correo (ej. <b>PW-2026-A1B2</b>) para ver el estado de tu envío.</div>
  <?php endif; ?>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
