# 🐾 PetWorld v2 — Guía de instalación en XAMPP

Versión rediseñada con tienda bonita, botón corazón (favoritos), compra como invitado, PayPal + Transferencia, correo con seguimiento y panel admin.

---

## 📂 Estructura de carpetas

```
PetWorld/
├── config.php                 ← Credenciales BD, PayPal, SMTP (EDITA ESTE)
├── conexion.php               ← Conexión PDO
├── index.php                  ← Inicio (hero, categorías, destacados)
├── catalogo.php               ← Catálogo con filtros + botón ♥
├── detalle.php                ← Detalle de producto + botón ♥ + agregar al carrito
├── carrito.php                ← Carrito con sesión PHP
├── favoritos.php              ← Lista de deseos (por sesión, sin login)
├── checkout.php               ← Checkout INVITADO con PayPal + Transferencia
├── pedidos_ok.php             ← Confirmación + código de seguimiento
├── seguimiento.php            ← Rastreo de envío por código
├── cuenta.php                 ← Mis pedidos (SOLO LECTURA, busca por correo)
├── includes/
│   ├── funciones.php          ← Carrito, favoritos, pedidos, helpers
│   ├── correo.php             ← Envío de correo con seguimiento
│   ├── navbar.php             ← Header con logo único + contadores
│   └── footer.php             ← Footer SIN logo
├── api/
│   ├── favoritos.php          ← Toggle ♥ vía AJAX
│   ├── paypal_crear_orden.php ← Crea orden PayPal (cURL REST)
│   └── paypal_capturar_orden.php ← Captura pago + crea pedido + correo
├── admin/
│   ├── auth.php               ← Verifica sesión admin
│   ├── login.php              ← admin@petworld.mx / admin123
│   ├── logout.php
│   ├── index.php              ← Dashboard con KPIs
│   ├── productos.php          ← CRUD de productos
│   └── pedidos.php            ← Gestión de pedidos
├── assets/
│   ├── css/styles.css         ← Diseño tienda mascotas (responsive)
│   ├── js/main.js             ← Carrito, favoritos AJAX, PayPal SDK
│   └── img/
│       ├── logo.svg           ← Logo único (solo header)
│       └── favicon.svg        ← Ícono de pestaña
└── database/
    └── petworld.sql           ← Esquema + datos de ejemplo
```

---

## ✅ Paso 1 — Copiar el proyecto a `htdocs`

Copia toda la carpeta `PetWorld/` a:

| Sistema | Ruta |
|---|---|
| Windows | `C:\xampp\htdocs\PetWorld\` |
| macOS   | `/Applications/XAMPP/htdocs/PetWorld/` |
| Linux   | `/opt/lampp/htdocs/PetWorld/` |

---

## 🟢 Paso 2 — Iniciar Apache + MySQL

En el Panel de Control de XAMPP: **Start** Apache y **Start** MySQL (deben quedar en verde).

---

## 🗄️ Paso 3 — Importar la base de datos

1. Abre **http://localhost/phpmyadmin**
2. Pestaña **Importar** → selecciona `PetWorld/database/petworld.sql`
3. Pulsa **Continuar**. Se crean 6 tablas:
   - `categorias` (5), `usuarios` (1 admin), `productos` (12),
     `pedidos` (3 ejemplos), `pedido_items`, `favoritos`

> Contraseña del admin: el hash en el SQL corresponde a **`admin123`** (puedes regenerarlo con `php -r "echo password_hash('tu_clave', PASSWORD_DEFAULT);"` y actualizar el INSERT).

---

## 🔧 Paso 4 — Configurar `config.php`

Abre `PetWorld/config.php` y edita:

### 4a) PayPal (para pagos reales o sandbox)
1. Crea cuenta en **https://developer.paypal.com**
2. Ve a *My Apps & Credentials* → crea una app **REST API** (sandbox o live)
3. Copia **Client ID** y **Secret** y pégalos:
```php
define('PAYPAL_CLIENT_ID',     'TU_CLIENT_ID_AQUI');
define('PAYPAL_CLIENT_SECRET', 'TU_SECRET_AQUI');
define('PAYPAL_MODE',          'sandbox');   // 'sandbox' para pruebas
```
> Mientras no los configures, el botón PayPal mostrará un mensaje claro. La transferencia bancaria SÍ funciona sin configurar nada.

### 4b) Correo (SMTP para envío real)
Para desarrollo local, la función `mail()` de PHP funciona sin configurar (los correos se loguean en `xampp/sendmail/`).
Para enviar correos reales, activa PHPMailer:
```php
define('SMTP_USAR_PHPMAILER', true);
define('SMTP_HOST',     'smtp.gmail.com');
define('SMTP_USER',     'tu_correo@gmail.com');
define('SMTP_PASSWORD', 'tu_app_password_16_chars');  // Google → App Passwords
```
Y descarga PHPMailer a `PetWorld/vendor/` (vía composer: `composer require phpmailer/phpmailer`).

### 4c) Datos bancarios (transferencia)
```php
define('BANCO_NOMBRE',   'Tu Banco');
define('BANCO_CLABE',    '012 345 6789 0123 4567');
define('BANCO_TITULAR',  'Tu Razón Social');
```

---

## 🌐 Paso 5 — Probar la tienda

👉 **http://localhost/PetWorld/index.php**

| Página | Qué probar |
|---|---|
| `index.php` | Hero bonito, 5 categorías, 8 productos destacados |
| `catalogo.php` | Filtros laterales + botón ♥ en cada card (toggle AJAX) |
| `detalle.php?id=1` | Galería, info, botón ♥, agregar al carrito |
| `favoritos.php` | Lista de deseos (sincroniza con los ♥ pulsados) |
| `carrito.php` | Items con eliminar, resumen, envío gratis desde $599 |
| `checkout.php` | Formulario de invitado + selector PayPal/Transferencia |
| `pedidos_ok.php?codigo=PW-2026-A1B2` | Confirmación + tracking |
| `seguimiento.php` | Buscar pedido por código |
| `cuenta.php` | Buscar pedidos por correo (SOLO LECTURA) |
| `admin/login.php` | Login admin (`admin@petworld.mx` / `admin123`) |

---

## 💳 Flujo de compra completo (pruébalo)

### Con Transferencia (sin configurar nada)
1. `detalle.php?id=2` → "Agregar al carrito"
2. `carrito.php` → "Proceder al pago"
3. `checkout.php` → llena nombre, correo, dirección
4. Selecciona **Transferencia** → "Confirmar pedido"
5. Se redirige a `pedidos_ok.php` con el **código de seguimiento**
6. Revisa `C:\xampp\mailoutput\` (o logs) → correo HTML con datos bancarios y tracking
7. `admin/pedidos.php` → el nuevo pedido aparece como `Pendiente / Procesando`

### Con PayPal (después de configurar `config.php`)
1. Mismo flujo hasta `checkout.php`
2. Selecciona **PayPal** → botón dorado del SDK
3. Inicia sesión con cuenta sandbox de comprador
4. Al aprobar → captura automática → `pedidos_ok.php`
5. Estado del pago en `admin/pedidos.php`: **Pagado**

---

## 🎨 Características del rediseño

- ✅ Logo **único** (solo en header; footer sin logo)
- ✅ **Favicon** SVG (icono en la pestaña del navegador)
- ✅ Diseño responsive (móvil, tablet, desktop)
- ✅ Paleta consistente: naranja #FF7A00 + menta #2EC4B6 + crema #FFF8F0
- ✅ Botón **corazón** en cada producto (favoritos persistentes)
- ✅ Tarjetas con hover, sombras, transiciones suaves
- ✅ Hero con gradiente y emojis decorativos
- ✅ Timeline visual de seguimiento (Procesando → En tránsito → Entregado)
- ✅ Badges de oferta (-20%) y novedades (Nuevo)

---

## 🔒 Seguridad y buenas prácticas

- **PDO + consultas preparadas reales** (`EMULATE_PREPARES=false`) → cero SQL injection
- **`password_verify()`** + hash bcrypt para login admin
- **`htmlspecialchars()`** en toda salida HTML → cero XSS
- **Transacción** `beginTransaction/commit/rollBack` al crear pedido
- **Snapshot** de items en `pedido_items` (aunque el producto cambie, el pedido conserva los datos del momento de compra)
- **Descuento de stock** automático tras cada compra
- **Cuenta de usuario SOLO LECTURA** → el cliente no puede editar sus datos; solo el admin
- **PayPal captura server-side** → el monto se valida contra el carrito real, no contra lo que envía el navegador

---

## 🆘 Problemas comunes

| Síntoma | Solución |
|---|---|
| 404 al pulsar un botón | Verifica que accedes por `http://localhost/PetWorld/...` y no con doble clic en el .php |
| "PayPal sin configurar" | Edita `config.php` con tus credenciales sandbox |
| cURL no funciona | En `php.ini` de XAMPP, descomenta `extension=curl` |
| El correo no llega | En dev local, revisa `C:\xampp\mailoutput\`. Para correo real, activa SMTP_USAR_PHPMAILER=true con Gmail App Password |
| "No se pudo conectar MySQL" | Verifica Apache+MySQL en verde, BD `petworld` creada |
| Ícono no carga en pestaña | Limpia caché del navegador; el favicon es `assets/img/favicon.svg` |

---

## 👥 Equipo
Daniel Campos Sotelo · Diony María Esparza Cruz · Kevin Alejandro Flores Acosta · Alan Josué García Casas
**Materia:** Negocios Electrónicos 1 · **Docente:** Luis Octavio Jiménez Cortés
**Institución:** Instituto Tecnológico de Aguascalientes — TecNM · **Fecha:** noviembre 2026
