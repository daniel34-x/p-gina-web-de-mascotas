<?php
/** catalogo.php · Vista 02 — Catálogo con filtros y botón corazón */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$cat    = isset($_GET['cat'])   ? (int)$_GET['cat']   : 0;
$q      = isset($_GET['q'])     ? trim($_GET['q'])    : '';
$precio = isset($_GET['price']) ? $_GET['price']      : 'all';
$oferta = isset($_GET['ofertas']);
$nuevo  = isset($_GET['new']);
$sort   = isset($_GET['sort'])  ? $_GET['sort']       : 'relevance';

try {
    $categorias = $conexion->query("SELECT c.id, c.nombre, c.icono, COUNT(p.id) AS total
        FROM categorias c LEFT JOIN productos p ON c.id = p.categoria_id
        GROUP BY c.id ORDER BY c.nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
    $marcas = $conexion->query("SELECT DISTINCT marca FROM productos
        WHERE marca IS NOT NULL AND marca != '' ORDER BY marca ASC")->fetchAll(PDO::FETCH_COLUMN);

    $sql = "SELECT p.*, c.nombre AS catLabel, c.color AS catColor
            FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE 1=1";
    $params = [];
    if ($cat > 0) { $sql .= " AND c.id = :cat"; $params[':cat'] = $cat; }
    if ($q !== '') { $sql .= " AND (p.nombre LIKE :q OR p.marca LIKE :q OR c.nombre LIKE :q)"; $params[':q'] = "%$q%"; }
    if ($precio === '0-300')      $sql .= " AND p.precio BETWEEN 0 AND 300";
    elseif ($precio === '300-700') $sql .= " AND p.precio BETWEEN 300 AND 700";
    elseif ($precio === '700-9999')$sql .= " AND p.precio >= 700";
    if ($oferta) $sql .= " AND p.etiqueta LIKE '-%'";
    if ($nuevo)  $sql .= " AND p.etiqueta = 'Nuevo'";
    switch ($sort) {
        case 'price-asc':  $sql .= " ORDER BY p.precio ASC"; break;
        case 'price-desc': $sql .= " ORDER BY p.precio DESC"; break;
        case 'rating':     $sql .= " ORDER BY p.calificacion DESC"; break;
        default:           $sql .= " ORDER BY p.destacado DESC, p.id ASC";
    }
    $stmt = $conexion->prepare($sql);
    $stmt->execute($params);
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $categorias = []; $marcas = []; $productos = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Catálogo · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar('catalogo'); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">🐾 Catálogo de Productos</div>
    <div class="breadcrumb">
      <a href="index.php">Inicio</a><span class="sep">/</span><span class="here">Catálogo</span>
    </div>
  </div>
</div>

<div class="catalog-layout">
  <aside class="filters">
    <form action="catalogo.php" method="GET" id="filter-form">
      <?php if ($q): ?><input type="hidden" name="q" value="<?= htmlspecialchars($q) ?>"><?php endif; ?>
      <input type="hidden" name="cat" id="input-cat" value="<?= htmlspecialchars($cat) ?>">
      <input type="hidden" name="sort" id="input-sort" value="<?= htmlspecialchars($sort) ?>">

      <h3>⚙ Filtros</h3>

      <div class="filter-group">
        <span class="filter-label">Categoría</span>
        <div class="filter-opt <?= $cat === 0 ? 'checked' : '' ?>" onclick="selectCat(0)">🐾 Todas</div>
        <?php foreach ($categorias as $c): ?>
          <div class="filter-opt <?= $cat === (int)$c['id'] ? 'checked' : '' ?>" onclick="selectCat(<?= (int)$c['id'] ?>)">
            <?= htmlspecialchars($c['icono']) ?> <?= htmlspecialchars($c['nombre']) ?> (<?= (int)$c['total'] ?>)
          </div>
        <?php endforeach; ?>
      </div>

      <div class="filter-group">
        <span class="filter-label">Marca</span>
        <?php foreach ($marcas as $b): ?>
          <div class="filter-opt">✓ <?= htmlspecialchars($b) ?></div>
        <?php endforeach; ?>
      </div>

      <div class="filter-group">
        <span class="filter-label">Precio</span>
        <label class="filter-opt"><input type="radio" name="price" value="all" <?= $precio==='all'?'checked':'' ?> onchange="this.form.submit()"> Todos</label>
        <label class="filter-opt"><input type="radio" name="price" value="0-300" <?= $precio==='0-300'?'checked':'' ?> onchange="this.form.submit()"> $0 – $300</label>
        <label class="filter-opt"><input type="radio" name="price" value="300-700" <?= $precio==='300-700'?'checked':'' ?> onchange="this.form.submit()"> $300 – $700</label>
        <label class="filter-opt"><input type="radio" name="price" value="700-9999" <?= $precio==='700-9999'?'checked':'' ?> onchange="this.form.submit()"> $700+</label>
      </div>

      <div class="filter-group">
        <span class="filter-label">Disponibilidad</span>
        <label class="filter-opt"><input type="checkbox" name="ofertas" <?= $oferta?'checked':'' ?> onchange="this.form.submit()"> En oferta</label>
        <label class="filter-opt"><input type="checkbox" name="new" <?= $nuevo?'checked':'' ?> onchange="this.form.submit()"> Nuevos</label>
      </div>

      <a href="catalogo.php" class="btn btn-ghost btn-block" style="margin-top:8px;">Limpiar filtros</a>
    </form>
  </aside>

  <main>
    <div class="catalog-toolbar">
      <div class="catalog-count">Mostrando <b><?= count($productos) ?></b> productos</div>
      <div>
        Ordenar por:
        <select class="select" id="sort-select" onchange="changeSort(this.value)">
          <option value="relevance"  <?= $sort==='relevance'?'selected':'' ?>>Más relevantes</option>
          <option value="price-asc"  <?= $sort==='price-asc'?'selected':'' ?>>Precio: menor a mayor</option>
          <option value="price-desc" <?= $sort==='price-desc'?'selected':'' ?>>Precio: mayor a menor</option>
          <option value="rating"     <?= $sort==='rating'?'selected':'' ?>>Mejor valorados</option>
        </select>
      </div>
    </div>

    <div class="product-grid">
      <?php if (!empty($productos)): foreach ($productos as $p) echo producto_card_html($p); ?>
      <?php else: ?>
        <div class="empty-state">
          <div class="ic">🔍</div>
          <h3>No se encontraron productos</h3>
          <p>Prueba con otros filtros.</p>
          <a href="catalogo.php" class="btn btn-primary" style="margin-top:16px;">Ver todo el catálogo</a>
        </div>
      <?php endif; ?>
    </div>
  </main>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
<script>
function selectCat(id){ document.getElementById('input-cat').value = id; document.getElementById('filter-form').submit(); }
function changeSort(v){ document.getElementById('input-sort').value = v; document.getElementById('filter-form').submit(); }
</script>
</body>
</html>
