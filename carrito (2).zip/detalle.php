<?php
/** detalle.php · Vista 03 — Detalle de producto con botón corazón */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$producto = null; $relacionados = [];

if ($id > 0) {
    try {
        $stmt = $conexion->prepare("SELECT p.*, c.nombre AS catLabel, c.color AS catColor
            FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE p.id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($producto) {
            $stmtR = $conexion->prepare("SELECT p.*, c.nombre AS catLabel, c.color AS catColor
                FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id
                WHERE p.categoria_id = :cid AND p.id <> :id
                ORDER BY p.destacado DESC, p.id ASC LIMIT 4");
            $stmtR->execute([':cid' => $producto['categoria_id'], ':id' => $id]);
            $relacionados = $stmtR->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) { $producto = null; }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $producto ? htmlspecialchars($producto['nombre']) . ' · ' : '' ?>PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar('catalogo'); ?>

<?php if ($producto):
    $fav = fav_is((int)$producto['id']);
    $desc_pct = '';
    if (!empty($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']) {
        $desc_pct = '<span class="desc">-' . number_format(100 - ($producto['precio']/$producto['precio_anterior']*100), 0) . '%</span>';
    }
?>
<div class="page-header">
  <div class="container">
    <a href="catalogo.php" class="back-btn">← Volver al catálogo</a>
    <div class="breadcrumb">
      <a href="index.php">Inicio</a><span class="sep">/</span>
      <a href="catalogo.php">Catálogo</a><span class="sep">/</span>
      <span class="here"><?= htmlspecialchars($producto['catLabel']) ?></span>
    </div>
  </div>
</div>

<div class="detalle">
  <div class="detalle-gallery">
    <button class="heart-btn <?= $fav ? 'is-fav' : '' ?>" data-id="<?= (int)$producto['id'] ?>" type="button" aria-label="Favorito" style="position:absolute;top:16px;right:16px;">
      <svg viewBox="0 0 24 24" width="24" height="24"><path d="M12 21s-7.5-4.7-10-9.2C.7 8.6 2 5 5.5 5c2 0 3.5 1.3 4.5 2.6C11 6.3 12.5 5 14.5 5 18 5 19.3 8.6 17 11.8 14.5 16.3 12 21 12 21z"/></svg>
    </button>
    <div class="big-emoji"><?= htmlspecialchars($producto['imagen']) ?></div>
  </div>

  <div class="detalle-info">
    <div class="cat-tag" style="color:<?= htmlspecialchars($producto['catColor']) ?>"><?= strtoupper(htmlspecialchars($producto['catLabel'])) ?></div>
    <h1><?= htmlspecialchars($producto['nombre']) ?></h1>
    <div class="marca">Marca: <b><?= htmlspecialchars($producto['marca']) ?></b></div>
    <div class="rating"><?= estrellas_html($producto['calificacion']) ?>
      <span class="n"><?= number_format($producto['calificacion'],1) ?> (<?= (int)$producto['total_resenas'] ?> reseñas)</span>
    </div>

    <div class="detalle-price">
      <span class="now"><?= money($producto['precio']) ?></span>
      <?php if (!empty($producto['precio_anterior']) && $producto['precio_anterior'] > $producto['precio']): ?>
        <span class="was"><?= money($producto['precio_anterior']) ?></span>
        <?= $desc_pct ?>
      <?php endif; ?>
    </div>

    <p class="detalle-desc"><?= nl2br(htmlspecialchars($producto['descripcion'])) ?></p>

    <div style="font-size:14px;margin:14px 0;">
      <?php if ((int)$producto['stock'] > 0): ?>
        <span class="stock-ok">✓ En stock (<?= (int)$producto['stock'] ?> disponibles)</span>
      <?php else: ?>
        <span class="stock-no">✗ Agotado</span>
      <?php endif; ?>
    </div>

    <form action="carrito.php?action=add" method="POST" class="add-cart-form">
      <input type="hidden" name="producto_id" value="<?= (int)$producto['id'] ?>">
      <input type="number" name="qty" value="1" min="1" max="99" class="qty-input">
      <button type="submit" class="btn btn-primary btn-lg" style="flex:1;">🛒 Agregar al carrito</button>
    </form>

    <a href="carrito.php" class="btn btn-ghost" style="margin-top:10px;">Ver carrito →</a>
  </div>
</div>

<?php if (!empty($relacionados)): ?>
<section class="related">
  <h2 class="section-title">Productos <span class="accent">relacionados</span></h2>
  <div class="product-grid">
    <?php foreach ($relacionados as $r) echo producto_card_html($r); ?>
  </div>
</section>
<?php endif; ?>

<?php else: ?>
<div class="empty-state" style="padding:80px 20px;">
  <div class="ic">🔍</div>
  <h3>Producto no encontrado</h3>
  <p>El ID <code><?= (int)$id ?></code> no existe en la base de datos.</p>
  <a href="catalogo.php" class="btn btn-primary" style="margin-top:16px;">← Volver al catálogo</a>
</div>
<?php endif; ?>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
</body>
</html>
