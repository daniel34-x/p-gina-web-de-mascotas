-- =====================================================================
--  PetWorld v2 · Base de datos MySQL para XAMPP
--  Incluye: favoritos (por sesión), pedidos para invitados con
--  seguimiento de envío, y estados de pedido.
--
--  Importar desde phpMyAdmin: pestaña Importar → este archivo.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS petworld
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE petworld;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pedido_items;
DROP TABLE IF EXISTS favoritos;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS categorias;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------- Categorías ----------------
CREATE TABLE categorias (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(80) NOT NULL,
    slug       VARCHAR(80) NOT NULL UNIQUE,
    icono      VARCHAR(10) DEFAULT '🐾',
    color      VARCHAR(20) DEFAULT '#FF7A00',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- Usuarios (solo ADMIN; los clientes compran como invitados) ----------------
CREATE TABLE usuarios (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nombre     VARCHAR(120) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,           -- hash con password_hash()
    rol        ENUM('admin') DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- Productos ----------------
CREATE TABLE productos (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    nombre          VARCHAR(150) NOT NULL,
    marca           VARCHAR(80)  DEFAULT NULL,
    categoria_id    INT NOT NULL,
    precio          DECIMAL(10,2) NOT NULL DEFAULT 0,
    precio_anterior DECIMAL(10,2) DEFAULT NULL,
    imagen          VARCHAR(150) DEFAULT '🐾',   -- emoji o nombre de archivo
    etiqueta        VARCHAR(20)  DEFAULT NULL,
    calificacion    DECIMAL(2,1) DEFAULT 5.0,
    total_resenas   INT DEFAULT 0,
    destacado       TINYINT(1) DEFAULT 0,
    descripcion     TEXT,
    stock           INT DEFAULT 0,
    creado_en       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_prod_cat FOREIGN KEY (categoria_id)
        REFERENCES categorias(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX idx_cat (categoria_id), INDEX idx_dest (destacado), INDEX idx_marca (marca)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- Pedidos (soporta compra INVITADA) ----------------
CREATE TABLE pedidos (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    codigo_seguimiento  VARCHAR(20) NOT NULL UNIQUE,    -- ej. PW-2026-AB12
    cliente_nombre      VARCHAR(120) NOT NULL,
    cliente_email       VARCHAR(150) NOT NULL,
    cliente_telefono    VARCHAR(20)  DEFAULT NULL,
    direccion_envio     TEXT NOT NULL,
    usuario_id          INT DEFAULT NULL,                -- NULL = invitado
    total               DECIMAL(10,2) NOT NULL DEFAULT 0,
    metodo_pago         ENUM('PayPal','Transferencia') DEFAULT 'PayPal',
    estado_pago         ENUM('Pendiente','Pagado','Cancelado') DEFAULT 'Pendiente',
    estado_envio        ENUM('Procesando','En tránsito','Entregado','Cancelado') DEFAULT 'Procesando',
    paypal_order_id     VARCHAR(50) DEFAULT NULL,
    fecha               DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ped_usr FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_seg (codigo_seguimiento), INDEX idx_email (cliente_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- Items por pedido (detalle de compra) ----------------
CREATE TABLE pedido_items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id   INT NOT NULL,
    producto_id INT NOT NULL,
    nombre      VARCHAR(150) NOT NULL,         -- snapshot al momento de comprar
    precio      DECIMAL(10,2) NOT NULL,
    cantidad    INT NOT NULL DEFAULT 1,
    CONSTRAINT fk_it_ped FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_it_prod FOREIGN KEY (producto_id)
        REFERENCES productos(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX idx_ped (pedido_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------- Favoritos (por sesión — no requiere login) ----------------
CREATE TABLE favoritos (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    session_id  VARCHAR(64) NOT NULL,
    producto_id INT NOT NULL,
    fecha       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_fav (session_id, producto_id),
    CONSTRAINT fk_fav_prod FOREIGN KEY (producto_id)
        REFERENCES productos(id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_sess (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================================
--  DATOS DE EJEMPLO
-- =====================================================================
INSERT INTO categorias (nombre, slug, icono, color) VALUES
('Perros',   'perros',   '🐶', '#FF7A00'),
('Gatos',    'gatos',    '🐱', '#2EC4B6'),
('Aves',     'aves',     '🦜', '#FFD60A'),
('Roedores', 'roedores', '🐹', '#A78BFA'),
('Peces',    'peces',    '🐠', '#3B82F6');

-- Admin por defecto: usuario=admin@petworld.mx  contraseña=admin123 (hash bcrypt)
INSERT INTO usuarios (id, nombre, email, password, rol) VALUES
(1, 'Administrador PetWorld', 'admin@petworld.mx',
    '$2y$10$N9qo8uLOickgx2ZMRZoMy.MwrD5yQ8Uu0GjZ4rx5.mYxRQX5oKb2m', 'admin');

INSERT INTO productos
    (nombre, marca, categoria_id, precio, precio_anterior, imagen, etiqueta, calificacion, total_resenas, destacado, descripcion, stock)
VALUES
('Croquetas Premium Adulto 3kg',  'Pedigree',  1, 285.00, 350.00, '🦴', '-20%', 4.7, 124, 1, 'Alimento completo y balanceado para perros adultos de todos los tamaños.', 50),
('Arena Sanitaria Premium 4kg',   'Catit',     2, 189.00, NULL,   '🪣', 'Nuevo',4.5,  38, 1, 'Arena aglomerante de alta absorción con control de olor.', 80),
('Juguete Interactivo Pelota',    'Kong',      1, 159.00, 199.00, '🎾', '-20%', 4.8, 210, 1, 'Pelota resistente de caucho natural para perros masticadores.', 120),
('Comida Viva para Aves 500g',    'Versele',   3,  95.00, NULL,   '🌾', NULL,   4.3,  18, 0, 'Mezcla nutritiva de semillas para canarios y periquitos.', 60),
('Acuario Rectangular 20L',       'Tetra',     5, 599.00, 750.00, '🐠', '-20%', 4.6,  45, 1, 'Acuario de vidrio con filtro incluido para peces tropicales.', 15),
('Rueda Ejercicio Roedores',      'Ferplast',  4, 125.00, NULL,   '⚙️', 'Nuevo',4.4,  22, 0, 'Rueda silenciosa de plástico resistente para hámsters.', 40),
('Antiparasitario Externo',       'Frontline', 1, 320.00, NULL,   '💉', NULL,   4.9, 350, 1, 'Tratamiento antipulgas y garrapatas de larga duración.', 75),
('Comida Húmeda Gato 85g',        'Whiskas',   2,  35.00,  45.00, '🥫', '-22%', 4.2, 180, 0, 'Lata de comida húmeda sabor atún para gatos adultos.', 200),
('Collar Cuero Perro Mediano',    'Petsport',  1, 145.00, NULL,   '🦮', NULL,   4.5,  67, 0, 'Collar de cuero genuino con hebilla metálica ajustable.', 90),
('Bebedero Automático Gatos',     'Catit',     2, 410.00, 520.00, '💧', '-21%', 4.7,  88, 1, 'Fuente de agua con filtro recirculante para gatos.', 25),
('Jaula Grande para Aves',        'Ferplast',  3, 890.00, NULL,   '🪶', NULL,   4.4,  12, 0, 'Jaula espaciosa con bandeja extraíble y accesorios.', 8),
('Comida Roedores Premium 1kg',   'Versele',   4, 110.00, 130.00, '🥕', '-15%', 4.6,  54, 0, 'Alimento completo para hámsters, conejos y cobayos.', 100);

-- Pedidos de ejemplo con códigos de seguimiento
INSERT INTO pedidos (codigo_seguimiento, cliente_nombre, cliente_email, cliente_telefono, direccion_envio, usuario_id, total, metodo_pago, estado_pago, estado_envio, fecha) VALUES
('PW-2026-A1B2', 'Diony Esparza',   'diony.esparza@petworld.mx',   '449 234 5678', 'Av. Tecnológico #203, Centro, Aguascalientes', NULL, 444.00, 'PayPal',       'Pagado',     'Entregado',   '2026-10-15 14:30:00'),
('PW-2026-C3D4', 'Kevin Flores',    'kevin.flores@petworld.mx',    '449 345 6789', 'Calle Jardín 45, Col. del Sol, Aguascalientes', NULL, 285.00, 'Transferencia','Pendiente',  'En tránsito', '2026-11-10 09:15:00'),
('PW-2026-E5F6', 'Alan García',     'alan.garcia@petworld.mx',     '449 456 7890', 'Privada Olivos 12, San Francisco, Ags.',         NULL, 745.00, 'PayPal',       'Pagado',     'En tránsito', '2026-11-15 11:20:00');

-- Verificación
SELECT 'categorias' t, COUNT(*) n FROM categorias
UNION ALL SELECT 'usuarios',  COUNT(*) FROM usuarios
UNION ALL SELECT 'productos', COUNT(*) FROM productos
UNION ALL SELECT 'pedidos',   COUNT(*) FROM pedidos;
