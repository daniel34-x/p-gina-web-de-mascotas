/* =====================================================================
   PetWorld · main.js — Carrito, favoritos (AJAX) y UI helpers
   ===================================================================== */
(function () {
  'use strict';

  // ---------- Toast ----------
  function showToast(msg, type) {
    let t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.background = type === 'error' ? '#E63946' : (type === 'ok' ? '#2D6A4F' : '#2A1F14');
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 2600);
  }
  window.showToast = showToast;

  // ---------- Navbar mobile ----------
  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('nav-toggle');
    const nav = document.querySelector('.nav');
    if (btn && nav) {
      btn.addEventListener('click', () => nav.classList.toggle('open'));
    }
  });

  // ---------- Favoritos: botón corazón (AJAX) ----------
  // Requiere endpoint: api/favoritos.php  (POST con producto_id)
  async function toggleFav(btn) {
    const id = btn.dataset.id;
    if (!id) return;
    btn.disabled = true;
    try {
      const fd = new FormData();
      fd.append('producto_id', id);
      const res = await fetch('api/favoritos.php', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.ok) {
        btn.classList.toggle('is-fav', data.fav);
        showToast(data.fav ? '♥ Añadido a favoritos' : 'Quitado de favoritos', 'ok');
        // Actualizar contador en navbar
        const badge = document.querySelector('.nav-icon-btn[aria-label="Favoritos"] .badge-count');
        if (badge) {
          if (data.count > 0) { badge.textContent = data.count; badge.style.display = 'flex'; }
          else badge.style.display = 'none';
        } else if (data.count > 0) {
          const favBtn = document.querySelector('.nav-icon-btn[aria-label="Favoritos"]');
          if (favBtn) {
            const b = document.createElement('span');
            b.className = 'badge-count';
            b.textContent = data.count;
            favBtn.appendChild(b);
          }
        }
      } else {
        showToast('Error al actualizar favoritos', 'error');
      }
    } catch (e) {
      showToast('No se pudo conectar con el servidor', 'error');
    } finally {
      btn.disabled = false;
    }
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.heart-btn');
    if (btn) {
      e.preventDefault();
      e.stopPropagation();
      toggleFav(btn);
    }
  });

  // ---------- Carrito: feedback al agregar ----------
  document.addEventListener('submit', (e) => {
    const f = e.target;
    if (f.classList.contains('prod-add') || f.classList.contains('add-cart-form')) {
      // dejamos que el form POST normalmente a carrito.php?action=add,
      // pero mostramos toast antes de redirigir
      showToast('🛒 Agregando al carrito...', 'ok');
    }
  });

  // ---------- PayPal SDK loader (usado en checkout.php) ----------
  window.loadPayPalSDK = function (clientId, currency, amount, onApproveCB, container) {
    if (!document.getElementById('paypal-sdk-script')) {
      const s = document.createElement('script');
      s.id = 'paypal-sdk-script';
      s.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${currency}&intent=capture`;
      s.onload = renderButtons;
      document.head.appendChild(s);
    } else {
      renderButtons();
    }
    function renderButtons() {
      if (!window.paypal) { console.error('PayPal SDK no cargó'); return; }
      window.paypal.Buttons({
        style: { layout: 'vertical', color: 'gold', shape: 'rect', label: 'pay' },
        createOrder: async () => {
          const fd = new FormData();
          // capturar datos del form de checkout
          document.querySelectorAll('#checkout-form input, #checkout-form select, #checkout-form textarea')
            .forEach(el => { if (el.name) fd.append(el.name, el.value); });
          fd.append('metodo_pago', 'PayPal');
          const res = await fetch('api/paypal_crear_orden.php', { method: 'POST', body: fd });
          const data = await res.json();
          if (!data.ok) { showToast('Error al crear orden PayPal: ' + (data.error || ''), 'error'); throw new Error(data.error); }
          return data.orderID;
        },
        onApprove: async (actions) => {
          // capturar del lado del servidor
          const fd = new FormData();
          fd.append('orderID', actions.orderID);
          document.querySelectorAll('#checkout-form input, #checkout-form select, #checkout-form textarea')
            .forEach(el => { if (el.name) fd.append(el.name, el.value); });
          const res = await fetch('api/paypal_capturar_orden.php', { method: 'POST', body: fd });
          const data = await res.json();
          if (data.ok && data.redirect) {
            showToast('✓ Pago aprobado. Redirigiendo...', 'ok');
            setTimeout(() => window.location.href = data.redirect, 1200);
          } else {
            showToast('Error al capturar el pago: ' + (data.error || ''), 'error');
          }
        },
        onError: (err) => {
          console.error('PayPal error:', err);
          showToast('Ocurrió un error con PayPal', 'error');
        }
      }).render(container || '#paypal-button-container');
    }
  };

  // ---------- Helper formato moneda ----------
  window.fmtMXN = (n) => '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

})();
