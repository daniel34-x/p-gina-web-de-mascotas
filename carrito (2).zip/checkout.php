<?php
/** checkout.php · Vista — Checkout INVITADO (sin login)
 *  - Método PayPal: botones SDK → api/paypal_capturar_orden.php
 *  - Método Transferencia: POST interno → crea pedido + correo → redirige a pedidos_ok.php
 */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';
require_once __DIR__ . '/includes/correo.php';
cart_init();

$items   = cart_items();
$subtotal= cart_subtotal();
$envio   = ($subtotal >= ENVIO_GRATIS_DESDE || $subtotal == 0) ? 0 : ENVIO_COSTO;
$total   = $subtotal + $envio;

// ===== Manejar POST de Transferencia =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['metodo_pago'] ?? '') === 'Transferencia') {
    $nombre   = trim($_POST['nombre'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion= trim($_POST['direccion'] ?? '');

    if ($nombre === '' || $email === '' || $direccion === '') {
        $error = 'Completa nombre, correo y dirección de envío.';
    } elseif (empty($items)) {
        $error = 'El carrito está vacío.';
    } else {
        $r = crear_pedido([
            'nombre'    => $nombre,
            'email'     => $email,
            'telefono'  => $telefono,
            'direccion' => $direccion,
            'metodo_pago'=> 'Transferencia',
            'paypal_order_id' => null,
            'usuario_id' => null,
        ]);
        if ($r['ok']) {
            enviar_correo_pedido((int)$r['pedido_id']);
            cart_clear();
            header('Location: pedidos_ok.php?codigo=' . urlencode($r['codigo']));
            exit;
        } else {
            $error = $r['error'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar(); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">💳 Finalizar Compra</div>
    <div class="breadcrumb"><a href="index.php">Inicio</a><span class="sep">/</span><a href="carrito.php">Carrito</a><span class="sep">/</span><span class="here">Checkout</span></div>
  </div>
</div>

<div class="checkout-layout">
  <!-- IZQ: formulario + método de pago -->
  <div>
    <?php if (!empty($error)): ?>
      <div class="alert alert-err">✗ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (empty($items)): ?>
      <div class="checkout-card empty-state">
        <div class="ic">🛒</div>
        <h3>No hay productos para comprar</h3>
        <a href="catalogo.php" class="btn btn-primary" style="margin-top:14px;">Ir al catálogo</a>
      </div>
    <?php else: ?>

    <form id="checkout-form" method="POST" action="checkout.php">
      <div class="checkout-card">
        <h2>👤 Datos de envío (compra como invitado)</h2>
        <div class="form-grid">
          <div class="field full">
            <label>Nombre completo *</label>
            <input type="text" name="nombre" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Correo electrónico *</label>
            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
          </div>
          <div class="field">
            <label>Teléfono</label>
            <input type="tel" name="telefono" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
          </div>
          <div class="field full">
            <label>Dirección de envío completa *</label>
            <textarea name="direccion" rows="2" required placeholder="Calle, número, colonia, ciudad, CP"><?= htmlspecialchars($_POST['direccion'] ?? '') ?></textarea>
          </div>
        </div>
      </div>

      <div class="checkout-card">
        <h2>💳 Método de pago</h2>
        <div class="pay-methods">
          <label class="pay-opt active" data-method="PayPal">
            <input type="radio" name="metodo_pago" value="PayPal" checked>
            <span class="pay-ic">🅿️</span>
            <span><b>PayPal</b><small>Pago seguro con tarjeta o cuenta PayPal</small></span>
          </label>
          <label class="pay-opt" data-method="Transferencia">
            <input type="radio" name="metodo_pago" value="Transferencia">
            <span class="pay-ic">🏦</span>
            <span><b>Transferencia bancaria</b><small>Recibirás los datos por correo</small></span>
          </label>
        </div>

        <!-- Botón Transferencia -->
        <div id="transfer-block" style="display:none;margin-top:14px;">
          <div class="banco-box">
            <b>🏦 Datos bancarios:</b><br>
            Banco: <?= BANCO_NOMBRE ?><br>
            CLABE: <b><?= BANCO_CLABE ?></b><br>
            Titular: <?= BANCO_TITULAR ?><br>
            <small>Al confirmar se generará tu código de referencia y te llegará por correo.</small>
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:12px;">Confirmar pedido (Transferencia) →</button>
        </div>

        <!-- Contenedor PayPal SDK -->
        <div id="paypal-block" style="margin-top:14px;">
          <div class="alert alert-info" style="margin-bottom:8px;">🔒 Pago procesado de forma segura por PayPal.</div>
          <div id="paypal-button-container"></div>
        </div>
      </div>
    </form>

    <?php endif; ?>
  </div>

  <!-- DER: resumen -->
  <div>
    <div class="cart-summary">
      <h2>📋 Tu pedido</h2>
      <?php foreach ($items as $it):
        $cant = $_SESSION['carrito'][$it['id']] ?? 1;
        $sub  = $it['precio'] * $cant;
      ?>
        <div class="summary-row">
          <span><?= (int)$cant ?>× <?= htmlspecialchars($it['nombre']) ?></span>
          <b><?= money($sub) ?></b>
        </div>
      <?php endforeach; ?>
      <div class="summary-row"><span>Subtotal</span><b><?= money($subtotal) ?></b></div>
      <div class="summary-row"><span>Envío</span><b><?= $envio === 0 ? 'Gratis' : money($envio) ?></b></div>
      <div class="summary-total"><span>Total</span><span class="v"><?= money($total) ?></span></div>
    </div>
    <div style="text-align:center;margin-top:14px;font-size:13px;color:var(--pw-gray);">
      🛡 Compra protegida · 📧 Recibirás confirmación por correo
    </div>
  </div>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
<script>
// Toggle entre PayPal / Transferencia
document.querySelectorAll('input[name="metodo_pago"]').forEach(r => {
  r.addEventListener('change', () => {
    document.querySelectorAll('.pay-opt').forEach(o => o.classList.remove('active'));
    r.closest('.pay-opt').classList.add('active');
    const m = r.value;
    document.getElementById('paypal-block').style.display    = (m === 'PayPal') ? 'block' : 'none';
    document.getElementById('transfer-block').style.display  = (m === 'Transferencia') ? 'block' : 'none';
  });
});

// Cargar PayPal SDK y renderizar botones
<?php if (!empty($items)): ?>
window.addEventListener('DOMContentLoaded', () => {
  window.loadPayPalSDK(
    '<?= PAYPAL_CLIENT_ID ?>',
    '<?= PAYPAL_CURRENCY ?>',
    <?= json_encode((float)$total) ?>,
    null,
    '#paypal-button-container'
  );
});
<?php endif; ?>
</script>
</body>
</html>
