<?php
/** api/favoritos.php — Toggle favorito (botón corazón) vía AJAX
 *  POST: producto_id  →  Devuelve JSON {ok, fav, count}
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/funciones.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método no permitido']);
    exit;
}

$idProd = (int)($_POST['producto_id'] ?? 0);
if ($idProd <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'producto_id inválido']);
    exit;
}

// Verificar que el producto exista
$stmt = $conexion->prepare("SELECT 1 FROM productos WHERE id = ? LIMIT 1");
$stmt->execute([$idProd]);
if (!$stmt->fetchColumn()) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Producto no existe']);
    exit;
}

$fav   = fav_toggle($idProd);
$count = fav_count();

echo json_encode([
    'ok'    => true,
    'fav'   => $fav,
    'count' => $count,
]);
