<?php
/** api/paypal_capturar_orden.php
 *  Recibe (FormData): orderID (PayPal) + nombre, email, telefono, direccion
 *  Captura el pago en PayPal → crea el pedido en BD → envía correo → responde JSON.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/funciones.php';
require_once __DIR__ . '/../includes/correo.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método no permitido']);
    exit;
}

$orderID   = trim($_POST['orderID'] ?? '');
$nombre    = trim($_POST['nombre']    ?? '');
$email     = trim($_POST['email']     ?? '');
$telefono  = trim($_POST['telefono']  ?? '');
$direccion = trim($_POST['direccion'] ?? '');

if ($orderID === '' || $nombre === '' || $email === '' || $direccion === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Faltan datos (orderID, nombre, email, direccion)']);
    exit;
}

cart_init();
if (empty($_SESSION['carrito'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Carrito vacío']);
    exit;
}

// ---------- 1) Access token ----------
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => PAYPAL_API_BASE . '/v1/oauth2/token',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
    CURLOPT_USERPWD => PAYPAL_CLIENT_ID . ':' . PAYPAL_CLIENT_SECRET,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
    CURLOPT_SSL_VERIFYPEER => PAYPAL_MODE === 'live',
    CURLOPT_SSL_VERIFYHOST => PAYPAL_MODE === 'live' ? 2 : 0,
]);
$tokenResp = json_decode(curl_exec($ch), true);
curl_close($ch);
$accessToken = $tokenResp['access_token'] ?? '';
if ($accessToken === '') {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => 'No se pudo obtener token PayPal']);
    exit;
}

// ---------- 2) Capturar la orden ----------
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => PAYPAL_API_BASE . '/v2/checkout/orders/' . urlencode($orderID) . '/capture',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => '{}',
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
    ],
    CURLOPT_SSL_VERIFYPEER => PAYPAL_MODE === 'live',
    CURLOPT_SSL_VERIFYHOST => PAYPAL_MODE === 'live' ? 2 : 0,
]);
$captureResp = curl_exec($ch);
$captureHttp = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($captureHttp < 200 || $captureHttp >= 300) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => 'PayPal capture HTTP ' . $captureHttp,
        'detalle' => $captureResp,
    ]);
    exit;
}

$captureData = json_decode($captureResp, true);
$status = $captureData['status'] ?? '';
if ($status !== 'COMPLETED') {
    http_response_code(402);
    echo json_encode(['ok' => false, 'error' => 'Pago no completado: ' . $status]);
    exit;
}

// ---------- 3) Crear pedido en BD (estado_pago=Pagado) ----------
$r = crear_pedido([
    'nombre'           => $nombre,
    'email'            => $email,
    'telefono'         => $telefono,
    'direccion'        => $direccion,
    'metodo_pago'      => 'PayPal',
    'paypal_order_id'  => $orderID,
    'usuario_id'       => null,
]);

if (!$r['ok']) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $r['error']]);
    exit;
}

// Marcar estado_pago = Pagado
$conexion->prepare("UPDATE pedidos SET estado_pago='Pagado' WHERE id = ?")
         ->execute([(int)$r['pedido_id']]);

// ---------- 4) Enviar correo ----------
enviar_correo_pedido((int)$r['pedido_id']);

// ---------- 5) Vaciar carrito y responder ----------
cart_clear();

echo json_encode([
    'ok' => true,
    'pedido_id' => $r['pedido_id'],
    'codigo'    => $r['codigo'],
    'redirect'  => 'pedidos_ok.php?codigo=' . urlencode($r['codigo']),
]);
