<?php
/** api/paypal_crear_orden.php
 *  Recibe (vía FormData) los datos del checkout form + metodo_pago=PayPal
 *  Llama a la API REST de PayPal para crear una Order con el total del carrito.
 *  Devuelve JSON {ok:true, orderID:"..."} o {ok:false, error:"..."}
 *
 *  Requisitos: extensión php_curl habilitada en XAMPP (viene activa por defecto).
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/funciones.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Método no permitido']);
    exit;
}

// Validar que PayPal esté configurado
if (strpos(PAYPAL_CLIENT_ID, 'YOUR_CLIENT_ID') !== false) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'PayPal sin configurar. Edita config.php con tu Client ID y Secret de https://developer.paypal.com',
    ]);
    exit;
}

// Verificar carrito
cart_init();
$total = cart_total_con_envio();
if ($total <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Carrito vacío']);
    exit;
}

// ---------- 1) Obtener access token ----------
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => PAYPAL_API_BASE . '/v1/oauth2/token',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
    CURLOPT_USERPWD => PAYPAL_CLIENT_ID . ':' . PAYPAL_CLIENT_SECRET,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
    CURLOPT_SSL_VERIFYPEER => PAYPAL_MODE === 'live',
    CURLOPT_SSL_VERIFYHOST => PAYPAL_MODE === 'live' ? 2 : 0,
]);
$tokenResp = curl_exec($ch);
$tokenHttp = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr   = curl_error($ch);
curl_close($ch);

if ($tokenHttp !== 200) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => 'PayPal token falló: ' . $curlErr . ' (HTTP ' . $tokenHttp . ')',
        'detalle' => $tokenResp,
    ]);
    exit;
}
$tokenData = json_decode($tokenResp, true);
$accessToken = $tokenData['access_token'] ?? '';

if ($accessToken === '') {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => 'PayPal no devolvió access_token']);
    exit;
}

// ---------- 2) Crear la orden ----------
$body = [
    'intent' => 'CAPTURE',
    'purchase_units' => [[
        'amount' => [
            'currency_code' => PAYPAL_CURRENCY,
            'value'         => number_format($total, 2, '.', ''),
        ],
        'description' => 'Compra PetWorld · ' . cart_count() . ' artículo(s)',
    ]],
    'application_context' => [
        'brand_name' => NOMBRE_TIENDA,
        'user_action' => 'PAY_NOW',
        'shipping_preference' => 'NO_SHIPPING',
    ],
];

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => PAYPAL_API_BASE . '/v2/checkout/orders',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($body),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
    ],
    CURLOPT_SSL_VERIFYPEER => PAYPAL_MODE === 'live',
    CURLOPT_SSL_VERIFYHOST => PAYPAL_MODE === 'live' ? 2 : 0,
]);
$orderResp = curl_exec($ch);
$orderHttp = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($orderHttp < 200 || $orderHttp >= 300) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => 'PayPal create-order HTTP ' . $orderHttp,
        'detalle' => $orderResp,
    ]);
    exit;
}
$orderData = json_decode($orderResp, true);
$orderID = $orderData['id'] ?? '';

if ($orderID === '') {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => 'PayPal no devolvió order ID', 'detalle' => $orderResp]);
    exit;
}

echo json_encode(['ok' => true, 'orderID' => $orderID]);
