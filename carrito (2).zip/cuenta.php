<?php
/** cuenta.php · Vista 05 — MI CUENTA (SOLO LECTURA)
 *  El usuario NO puede editar sus datos (bloqueado).
 *  Toda actualización se hace desde el panel admin.
 *  Aquí solo consulta sus pedidos por correo electrónico.
 */
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/includes/funciones.php';
require_once __DIR__ . '/includes/navbar.php';
require_once __DIR__ . '/includes/footer.php';

$email = isset($_GET['email']) ? trim($_GET['email']) : (isset($_POST['email']) ? trim($_POST['email']) : '');
$pedidos = []; $cliente = null;

if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    try {
        $stmt = $conexion->prepare("SELECT * FROM pedidos WHERE cliente_email = ? ORDER BY fecha DESC");
        $stmt->execute([$email]);
        $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($pedidos)) {
            $cliente = [
                'nombre'   => $pedidos[0]['cliente_nombre'],
                'email'    => $pedidos[0]['cliente_email'],
                'telefono' => $pedidos[0]['cliente_telefono'],
                'direccion'=> $pedidos[0]['direccion_envio'],
            ];
        }
    } catch (PDOException $e) { $pedidos = []; }
}

$totalPedidos = count($pedidos);
$entregados   = count(array_filter($pedidos, fn($o) => $o['estado_envio'] === 'Entregado'));
$enTransito   = count(array_filter($pedidos, fn($o) => $o['estado_envio'] === 'En tránsito'));
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis pedidos · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<?php render_navbar('cuenta'); ?>

<div class="page-header">
  <div class="container">
    <div class="page-title">👤 Mis Pedidos</div>
    <div class="breadcrumb"><a href="index.php">Inicio</a><span class="sep">/</span><span class="here">Mi cuenta</span></div>
  </div>
</div>

<div class="container" style="padding:20px;">
  <div class="alert alert-info" style="margin-bottom:20px;">
    🔒 <b>Tu cuenta está protegida.</b> Por seguridad, tus datos personales solo pueden ser actualizados por el equipo de PetWorld desde el panel de administrador. Si necesitas corregir algo, escríbenos a <?= SMTP_FROM ?>.
  </div>
</div>

<div class="account-layout">
  <aside class="account-side">
    <div class="account-card">
      <div class="avatar"><?= $cliente ? strtoupper(substr($cliente['nombre'],0,1)) : '?' ?></div>
      <div style="font-weight:700;font-size:15px;"><?= $cliente ? htmlspecialchars($cliente['nombre']) : 'Invitado' ?></div>
      <div style="color:var(--pw-gray);font-size:13px;"><?= $cliente ? htmlspecialchars($cliente['email']) : 'Ingresa tu correo' ?></div>
      <span class="lock-badge">🔒 Solo lectura</span>
    </div>
    <div class="acc-menu">
      <div class="am-item active" data-tab="pedidos">📦 Mis pedidos <span class="pill"><?= $totalPedidos ?></span></div>
      <div class="am-item" data-tab="datos">👤 Datos personales</div>
      <div class="am-item" data-tab="direcciones">📍 Dirección de envío</div>
      <div class="am-item" data-tab="ayuda">💬 Soporte</div>
    </div>
  </aside>

  <main class="account-main">
    <!-- Buscar por email -->
    <form method="POST" action="cuenta.php" style="display:flex;gap:10px;margin-bottom:20px;">
      <input type="email" name="email" placeholder="Tu correo electrónico" value="<?= htmlspecialchars($email) ?>"
             style="flex:1;padding:12px 14px;border:1.5px solid var(--pw-line);border-radius:8px;font-size:14px;">
      <button type="submit" class="btn btn-primary">Consultar mis pedidos</button>
    </form>

    <div id="tab-content">
      <?php if ($email === ''): ?>
        <div class="empty-state">
          <div class="ic">📧</div>
          <h3>Ingresa tu correo para ver tus pedidos</h3>
          <p>Como compraste como invitado, usamos tu correo para encontrar tus órdenes.</p>
        </div>
      <?php elseif (empty($pedidos)): ?>
        <div class="empty-state">
          <div class="ic">📭</div>
          <h3>No encontramos pedidos para <?= htmlspecialchars($email) ?></h3>
          <p>Verifica el correo o <a href="catalogo.php" style="color:var(--pw-orange);font-weight:600;">realiza tu primera compra →</a></p>
        </div>
      <?php else: ?>
        <!-- Stats -->
        <div class="stat-grid">
          <div class="stat-card"><div class="ic">📦</div><div class="lbl">Pedidos</div><div class="val"><?= $totalPedidos ?></div></div>
          <div class="stat-card"><div class="ic">✓</div><div class="lbl">Entregados</div><div class="val"><?= $entregados ?></div></div>
          <div class="stat-card"><div class="ic">⏳</div><div class="lbl">En tránsito</div><div class="val"><?= $enTransito ?></div></div>
          <div class="stat-card"><div class="ic">⭐</div><div class="lbl">Cliente</div><div class="val" style="font-size:14px;">Gold</div></div>
        </div>

        <h2 style="font-family:'Poppins',sans-serif;font-size:17px;margin:24px 0 12px;">Historial completo</h2>
        <table class="table">
          <thead><tr>
            <th>Pedido</th><th>Fecha</th><th>Método</th><th>Total</th><th>Estado envío</th><th>Acción</th>
          </tr></thead>
          <tbody>
            <?php foreach ($pedidos as $o):
              $estPill = ['Procesando'=>'pill-yellow','En tránsito'=>'pill-blue','Entregado'=>'pill-green','Cancelado'=>'pill-red'];
              $cls = $estPill[$o['estado_envio']] ?? 'pill-yellow';
            ?>
              <tr>
                <td><b>#<?= htmlspecialchars($o['codigo_seguimiento']) ?></b></td>
                <td><?= date('d/m/Y', strtotime($o['fecha'])) ?></td>
                <td><?= htmlspecialchars($o['metodo_pago']) ?></td>
                <td><b><?= money($o['total']) ?></b></td>
                <td><span class="pill <?= $cls ?>"><?= htmlspecialchars($o['estado_envio']) ?></span></td>
                <td><a href="seguimiento.php?codigo=<?= urlencode($o['codigo_seguimiento']) ?>" style="color:var(--pw-orange);font-weight:600;">Rastrear →</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <!-- Tabs adicionales (solo lectura) -->
    <div id="tab-datos" style="display:none;">
      <h2 style="font-family:'Poppins',sans-serif;font-size:17px;margin-bottom:14px;">Datos personales (solo lectura)</h2>
      <?php if ($cliente): ?>
        <div class="info-row"><label>Nombre</label><span><?= htmlspecialchars($cliente['nombre']) ?></span></div>
        <div class="info-row"><label>Correo</label><span><?= htmlspecialchars($cliente['email']) ?></span></div>
        <div class="info-row"><label>Teléfono</label><span><?= htmlspecialchars($cliente['telefono'] ?: '—') ?></span></div>
        <div class="alert alert-info" style="margin-top:14px;">🔒 Para actualizar tus datos, contacta a <?= SMTP_FROM ?></div>
      <?php else: ?>
        <div class="empty-state"><div class="ic">📭</div><h3>Consulta tus pedidos primero</h3></div>
      <?php endif; ?>
    </div>

    <div id="tab-direcciones" style="display:none;">
      <h2 style="font-family:'Poppins',sans-serif;font-size:17px;margin-bottom:14px;">Dirección de envío (solo lectura)</h2>
      <?php if ($cliente): ?>
        <div class="info-row"><label>Dirección</label><span style="max-width:60%;"><?= htmlspecialchars($cliente['direccion']) ?></span></div>
        <div class="alert alert-info" style="margin-top:14px;">🔒 Para cambiar tu dirección, edita el pedido desde el panel admin.</div>
      <?php else: ?>
        <div class="empty-state"><div class="ic">📭</div><h3>Consulta tus pedidos primero</h3></div>
      <?php endif; ?>
    </div>

    <div id="tab-ayuda" style="display:none;">
      <h2 style="font-family:'Poppins',sans-serif;font-size:17px;margin-bottom:14px;">Soporte</h2>
      <div class="info-row"><label>📧 Correo</label><span><?= SMTP_FROM ?></span></div>
      <div class="info-row"><label>📍 Dirección</label><span>Av. Tecnológico #203, Aguascalientes</span></div>
      <div class="info-row"><label>🕘 Horario</label><span>Lun-Vie 9:00 - 18:00</span></div>
    </div>
  </main>
</div>

<?php render_footer(); ?>
<script src="assets/js/main.js"></script>
<script>
document.querySelectorAll('.am-item').forEach(el => el.addEventListener('click', () => {
  document.querySelectorAll('.am-item').forEach(x => x.classList.remove('active'));
  el.classList.add('active');
  const tab = el.dataset.tab;
  ['tab-content','tab-datos','tab-direcciones','tab-ayuda'].forEach(id => {
    document.getElementById(id).style.display = 'none';
  });
  const map = { pedidos:'tab-content', datos:'tab-datos', direcciones:'tab-direcciones', ayuda:'tab-ayuda' };
  document.getElementById(map[tab] || 'tab-content').style.display = 'block';
}));
</script>
</body>
</html>
