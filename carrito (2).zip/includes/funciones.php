<?php
/**
 * includes/funciones.php — Helpers compartidos
 * Cart (sesión), favoritos (BD por sesión), tracking, formato.
 */
require_once __DIR__ . '/../conexion.php';

// ============================ Carrito (sesión) ============================
function cart_init(): void {
    if (!isset($_SESSION['carrito']) || !is_array($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }
}

function cart_add(int $idProd, int $qty = 1): void {
    cart_init();
    $_SESSION['carrito'][$idProd] = ($_SESSION['carrito'][$idProd] ?? 0) + max(1, $qty);
}

function cart_remove(int $idProd): void {
    cart_init();
    unset($_SESSION['carrito'][$idProd]);
}

function cart_clear(): void {
    $_SESSION['carrito'] = [];
}

function cart_count(): int {
    cart_init();
    return array_sum($_SESSION['carrito']);
}

function cart_items(): array {
    global $conexion;
    cart_init();
    if (empty($_SESSION['carrito'])) return [];
    $ids = array_filter(array_map('intval', array_keys($_SESSION['carrito'])));
    if (empty($ids)) return [];
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conexion->prepare(
        "SELECT p.*, c.nombre AS catLabel, c.color AS catColor
         FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id
         WHERE p.id IN ($ph)"
    );
    $stmt->execute($ids);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function cart_subtotal(): float {
    $items = cart_items();
    $sum = 0;
    foreach ($items as $it) {
        $sum += $it['precio'] * ($_SESSION['carrito'][$it['id']] ?? 1);
    }
    return (float)$sum;
}

function cart_total_con_envio(): float {
    $sub = cart_subtotal();
    $envio = ($sub >= ENVIO_GRATIS_DESDE || $sub == 0) ? 0 : ENVIO_COSTO;
    return $sub + $envio;
}

// ============================ Favoritos (BD por sesión) ============================
function fav_toggle(int $idProd): bool {
    global $conexion;
    $sid = GUEST_SID;
    // ¿ya está?
    $stmt = $conexion->prepare("SELECT id FROM favoritos WHERE session_id=? AND producto_id=?");
    $stmt->execute([$sid, $idProd]);
    if ($stmt->fetch()) {
        $del = $conexion->prepare("DELETE FROM favoritos WHERE session_id=? AND producto_id=?");
        $del->execute([$sid, $idProd]);
        return false;   // se quitó
    }
    $ins = $conexion->prepare("INSERT IGNORE INTO favoritos (session_id, producto_id) VALUES (?, ?)");
    $ins->execute([$sid, $idProd]);
    return true;        // se agregó
}

function fav_count(): int {
    global $conexion;
    $stmt = $conexion->prepare("SELECT COUNT(*) FROM favoritos WHERE session_id=?");
    $stmt->execute([GUEST_SID]);
    return (int)$stmt->fetchColumn();
}

function fav_is(int $idProd): bool {
    global $conexion;
    $stmt = $conexion->prepare("SELECT 1 FROM favoritos WHERE session_id=? AND producto_id=? LIMIT 1");
    $stmt->execute([GUEST_SID, $idProd]);
    return (bool)$stmt->fetchColumn();
}

function fav_ids(): array {
    global $conexion;
    $stmt = $conexion->prepare("SELECT producto_id FROM favoritos WHERE session_id=? ORDER BY fecha DESC");
    $stmt->execute([GUEST_SID]);
    return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'producto_id');
}

function fav_products(): array {
    global $conexion;
    $ids = fav_ids();
    if (empty($ids)) return [];
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conexion->prepare(
        "SELECT p.*, c.nombre AS catLabel, c.color AS catColor
         FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id
         WHERE p.id IN ($ph)"
    );
    $stmt->execute(array_map('intval', $ids));
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ============================ Pedidos ============================
function generar_codigo_seguimiento(): string {
    $year = date('Y');
    $rand = strtoupper(substr(bin2hex(random_bytes(2)), 0, 4));
    return "PW-{$year}-{$rand}";
}

function crear_pedido(array $datos): array {
    /**
     * $datos = [
     *   'nombre','email','telefono','direccion',
     *   'metodo_pago' ('PayPal'|'Transferencia'),
     *   'paypal_order_id' (string|null),
     *   'usuario_id' (int|null)
     * ]
     * Devuelve ['ok'=>bool, 'pedido_id'=>int|null, 'codigo'=>string|null, 'error'=>string|null]
     */
    global $conexion;
    try {
        $conexion->beginTransaction();

        $items = cart_items();
        if (empty($items)) throw new Exception('El carrito está vacío.');

        $total   = cart_total_con_envio();
        $codigo  = generar_codigo_seguimiento();

        $stmt = $conexion->prepare(
            "INSERT INTO pedidos
             (codigo_seguimiento, cliente_nombre, cliente_email, cliente_telefono,
              direccion_envio, usuario_id, total, metodo_pago, estado_pago,
              estado_envio, paypal_order_id, fecha)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
        );

        $estado_pago = ($datos['metodo_pago'] === 'PayPal' && !empty($datos['paypal_order_id']))
            ? 'Pagado' : 'Pendiente';

        $stmt->execute([
            $codigo,
            trim($datos['nombre']),
            trim($datos['email']),
            trim($datos['telefono'] ?? ''),
            trim($datos['direccion']),
            $datos['usuario_id'] ?? null,
            $total,
            $datos['metodo_pago'],
            $estado_pago,
            'Procesando',
            $datos['paypal_order_id'] ?? null,
        ]);
        $pedidoId = (int)$conexion->lastInsertId();

        // snapshot de items
        $stmtItem = $conexion->prepare(
            "INSERT INTO pedido_items (pedido_id, producto_id, nombre, precio, cantidad)
             VALUES (?, ?, ?, ?, ?)"
        );
        foreach ($items as $it) {
            $cant = $_SESSION['carrito'][$it['id']] ?? 1;
            $stmtItem->execute([
                $pedidoId, (int)$it['id'], $it['nombre'], $it['precio'], (int)$cant
            ]);
            // descontar stock
            $conexion->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?")
                     ->execute([(int)$cant, (int)$it['id']]);
        }

        $conexion->commit();
        return ['ok' => true, 'pedido_id' => $pedidoId, 'codigo' => $codigo, 'total' => $total];
    } catch (Exception $e) {
        $conexion->rollBack();
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

// ============================ Formateo ============================
function money($n): string {
    return SIMBOLO_MONEDA . number_format((float)$n, 2);
}

function estrellas_html($rating): string {
    $r = round((float)$rating);
    $h = '';
    for ($i = 0; $i < 5; $i++) $h .= $i < $r ? '★' : '☆';
    return $h;
}

function badge_color(?string $etiqueta): string {
    if ($etiqueta === null || $etiqueta === '') return '#999';
    return (str_starts_with($etiqueta, '-')) ? '#E63946' : '#2EC4B6';
}

function producto_card_html(array $p): string {
    $id       = (int)$p['id'];
    $fav      = fav_is($id) ? 'is-fav' : '';
    $color    = htmlspecialchars($p['catColor'] ?? '#FF7A00');
    $nombre   = htmlspecialchars($p['nombre']);
    $emoji    = htmlspecialchars($p['imagen'] ?? '🐾');
    $catLabel = htmlspecialchars($p['catLabel'] ?? '');
    $rating   = number_format((float)($p['calificacion'] ?? 5), 1);
    $resenas  = (int)($p['total_resenas'] ?? 0);
    $precio   = money($p['precio']);

    $badge = '';
    if (!empty($p['etiqueta'])) {
        $bc = badge_color($p['etiqueta']);
        $badge = '<span class="badge" style="background:' . $bc . '">'
               . htmlspecialchars($p['etiqueta']) . '</span>';
    }
    $precio_ant = '';
    if (!empty($p['precio_anterior']) && $p['precio_anterior'] > $p['precio']) {
        $precio_ant = '<span class="precio-tachado">' . money($p['precio_anterior']) . '</span>';
    }

    $est = estrellas_html($p['calificacion'] ?? 5);

    return <<<HTML
    <article class="product-card" style="--cat:{$color}">
        <button class="heart-btn {$fav}" data-id="{$id}" type="button" aria-label="Favorito">
            <svg viewBox="0 0 24 24" width="20" height="20"><path d="M12 21s-7.5-4.7-10-9.2C.7 8.6 2 5 5.5 5c2 0 3.5 1.3 4.5 2.6C11 6.3 12.5 5 14.5 5 18 5 19.3 8.6 17 11.8 14.5 16.3 12 21 12 21z"/></svg>
        </button>
        {$badge}
        <a href="detalle.php?id={$id}" class="prod-thumb">
            <span class="prod-emoji">{$emoji}</span>
        </a>
        <div class="prod-body">
            <span class="prod-cat">{$catLabel}</span>
            <h3 class="prod-name"><a href="detalle.php?id={$id}">{$nombre}</a></h3>
            <div class="prod-rating">{$est} <span class="rating-num">{$rating} ({$resenas})</span></div>
            <div class="prod-price">
                <span class="precio">{$precio}</span>{$precio_ant}
            </div>
        </div>
        <form action="carrito.php?action=add" method="POST" class="prod-add">
            <input type="hidden" name="producto_id" value="{$id}">
            <input type="hidden" name="qty" value="1">
            <button type="submit" class="btn btn-primary btn-sm">+ Agregar</button>
        </form>
    </article>
    HTML;
}
