<?php
/**
 * includes/footer.php — Footer reutilizable. Sin logo (el logo solo va en header).
 * Uso:  require_once 'includes/footer.php';  render_footer();
 */
require_once __DIR__ . '/../config.php';

function render_footer(): void {
    $year = date('Y');
    echo <<<HTML
    <footer class="footer">
      <div class="container footer-grid">
        <div class="footer-col">
          <h4>PetWorld</h4>
          <p>Tienda en línea de mascotas · Proyecto académico de Negocios Electrónicos 1.</p>
        </div>
        <div class="footer-col">
          <h4>Navegación</h4>
          <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="catalogo.php">Catálogo</a></li>
            <li><a href="favoritos.php">Favoritos</a></li>
            <li><a href="carrito.php">Carrito</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Soporte</h4>
          <ul>
            <li><a href="seguimiento.php">Rastrear pedido</a></li>
            <li><a href="cuenta.php">Mis pedidos</a></li>
            <li><a href="admin/login.php">Acceso admin</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Contacto</h4>
          <p>Av. Tecnológico #203<br>Aguascalientes, México<br>📧 no-reply@petworld.mx</p>
        </div>
      </div>
      <div class="footer-bottom">
        © {$year} PetWorld · Instituto Tecnológico de Aguascalientes — TecNM
      </div>
    </footer>
    HTML;
}
