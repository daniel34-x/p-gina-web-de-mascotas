<?php
/**
 * includes/correo.php — Envío de correo con confirmación y seguimiento.
 *
 * Por defecto usa mail() de PHP (configura sendmail en XAMPP php.ini).
 * Si SMTP_USAR_PHPMAILER = true y tienes PHPMailer instalado, usa SMTP real.
 *
 * Función principal: enviar_correo_pedido($pedidoId)
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';

/**
 * Carga PHPMailer si está disponible (vía composer o descarga directa).
 */
function _cargar_phpmailer(): bool {
    $paths = [
        __DIR__ . '/../vendor/autoload.php',
        __DIR__ . '/../includes/PHPMailer/src/PHPMailer.php',
    ];
    foreach ($paths as $p) {
        if (file_exists($p)) {
            require_once $p;
            return true;
        }
    }
    return false;
}

/**
 * Envía correo usando SMTP (PHPMailer). Requiere SMTP_USAR_PHPMAILER=true y PHPMailer instalado.
 */
function _enviar_smtp(string $to, string $subject, string $htmlBody, string $textBody = ''): bool {
    if (!_cargar_phpmailer()) {
        error_log('PHPMailer no instalado. Bajando a mail().');
        return _enviar_mail_nativo($to, $subject, $htmlBody, $textBody);
    }
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';
        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body    = $htmlBody;
        $mail->AltBody = $textBody ?: strip_tags($htmlBody);
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Envía correo con mail() nativo de PHP (XAMPP sendmail).
 */
function _enviar_mail_nativo(string $to, string $subject, string $htmlBody, string $textBody = ''): bool {
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-Type: text/html; charset=UTF-8' . "\r\n";
    $headers .= 'From: ' . SMTP_FROM_NAME . ' <' . SMTP_FROM . '>' . "\r\n";
    return @mail($to, $subject, $htmlBody, $headers);
}

/**
 * Función pública para enviar correo.
 */
function enviar_correo(string $to, string $subject, string $html, string $text = ''): bool {
    if (SMTP_USAR_PHPMAILER) {
        return _enviar_smtp($to, $subject, $html, $text);
    }
    return _enviar_mail_nativo($to, $subject, $html, $text);
}

/**
 * Genera el HTML del correo de confirmación de pedido con seguimiento.
 */
function html_correo_pedido(array $pedido, array $items): string {
    $codigo   = htmlspecialchars($pedido['codigo_seguimiento']);
    $nombre   = htmlspecialchars($pedido['cliente_nombre']);
    $email    = htmlspecialchars($pedido['cliente_email']);
    $total    = money($pedido['total']);
    $metodo   = htmlspecialchars($pedido['metodo_pago']);
    $estado   = htmlspecialchars($pedido['estado_envio']);
    $direccion= htmlspecialchars($pedido['direccion_envio']);
    $fecha    = date('d/m/Y H:i', strtotime($pedido['fecha']));
    $urlTrack = TIENDA_URL . '/seguimiento.php?codigo=' . urlencode($codigo);

    $rows = '';
    foreach ($items as $it) {
        $sub = $it['precio'] * $it['cantidad'];
        $rows .= '<tr>'
              . '<td style="padding:8px;border-bottom:1px solid #eee;">' . htmlspecialchars($it['nombre']) . '</td>'
              . '<td style="padding:8px;border-bottom:1px solid #eee;text-align:center;">' . (int)$it['cantidad'] . '</td>'
              . '<td style="padding:8px;border-bottom:1px solid #eee;text-align:right;">' . money($sub) . '</td>'
              . '</tr>';
    }

    $extraBanco = '';
    if ($metodo === 'Transferencia') {
        $extraBanco = '
        <div style="background:#FFF8F0;border-left:4px solid #FF7A00;padding:14px;margin:16px 0;border-radius:6px;">
          <b>💳 Datos para tu transferencia:</b><br>
          Banco: ' . BANCO_NOMBRE . '<br>
          Cuenta CLABE: <b>' . BANCO_CLABE . '</b><br>
          Titular: ' . BANCO_TITULAR . '<br>
          Referencia: <b>' . $codigo . '</b><br>
          <small>Una vez realizada la transferencia, envía tu comprobante a ' . SMTP_FROM . ' para confirmar el pago.</small>
        </div>';
    }

    return <<<HTML
<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#FFF8F0;font-family:'Segoe UI',Arial,sans-serif;color:#2A1F14;">
  <div style="max-width:600px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,.08);">
    <div style="background:linear-gradient(135deg,#FF7A00,#FFB347);padding:24px;color:#fff;">
      <h1 style="margin:0;font-size:22px;">🐾 PetWorld — ¡Gracias por tu compra, {$nombre}!</h1>
      <p style="margin:6px 0 0;opacity:.95;">Hemos registrado tu pedido correctamente.</p>
    </div>
    <div style="padding:24px;">
      <div style="background:#d1fae5;color:#065f46;padding:14px;border-radius:8px;text-align:center;margin-bottom:16px;">
        <b>Código de seguimiento:</b> {$codigo}<br>
        <small>Estado actual: {$estado}</small>
      </div>
      <p>Estimado/a <b>{$nombre}</b>,</p>
      <p>Tu pedido fue registrado el {$fecha}. Aquí tienes el detalle:</p>
      <table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;">
        <thead><tr style="background:#f9f9f9;">
          <th style="padding:8px;text-align:left;">Producto</th>
          <th style="padding:8px;text-align:center;">Cant.</th>
          <th style="padding:8px;text-align:right;">Subtotal</th>
        </tr></thead>
        <tbody>{$rows}</tbody>
        <tfoot><tr>
          <td colspan="2" style="padding:12px;text-align:right;font-weight:700;">Total:</td>
          <td style="padding:12px;text-align:right;font-weight:700;color:#FF7A00;font-size:18px;">{$total}</td>
        </tr></tfoot>
      </table>
      {$extraBanco}
      <div style="background:#f4f4f4;padding:12px;border-radius:8px;margin:14px 0;font-size:13px;">
        <b>📍 Dirección de envío:</b><br>{$direccion}<br>
        <b>💳 Método de pago:</b> {$metodo}
      </div>
      <div style="text-align:center;margin:20px 0;">
        <a href="{$urlTrack}" style="display:inline-block;background:#FF7A00;color:#fff;text-decoration:none;padding:12px 24px;border-radius:8px;font-weight:700;">
          📦 Rastrear mi envío →
        </a>
      </div>
      <p style="font-size:12px;color:#999;text-align:center;margin-top:24px;">
        Este correo fue enviado automáticamente por PetWorld. No respondas a este mensaje.<br>
        © 2026 PetWorld · Instituto Tecnológico de Aguascalientes
      </p>
    </div>
  </div>
</body></html>
HTML;
}

/**
 * Envía el correo de confirmación de un pedido por su ID.
 * Devuelve true/false.
 */
function enviar_correo_pedido(int $pedidoId): bool {
    global $conexion;
    $stmt = $conexion->prepare("SELECT * FROM pedidos WHERE id = ?");
    $stmt->execute([$pedidoId]);
    $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$pedido) return false;

    $stmtI = $conexion->prepare("SELECT * FROM pedido_items WHERE pedido_id = ?");
    $stmtI->execute([$pedidoId]);
    $items = $stmtI->fetchAll(PDO::FETCH_ASSOC);

    $html = html_correo_pedido($pedido, $items);
    $asunto = '🐾 PetWorld · Pedido ' . $pedido['codigo_seguimiento'];
    return enviar_correo($pedido['cliente_email'], $asunto, $html);
}
