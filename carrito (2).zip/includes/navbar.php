<?php
/**
 * includes/navbar.php — Header reutilizable con carrito y favoritos.
 * Uso:  require_once 'includes/navbar.php';  render_navbar('catalogo');
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/funciones.php';

function render_navbar(string $activo = ''): void {
    $cartCount = cart_count();
    $favCount  = fav_count();
    $navItems = [
        'index'    => ['index.php',    'Inicio'],
        'catalogo' => ['catalogo.php', 'Catálogo'],
        'cuenta'   => ['cuenta.php',   'Mis pedidos'],
    ];
    echo '<header class="header">';
    echo '<div class="container nav-container">';
    echo '<a href="index.php" class="logo" aria-label="PetWorld">';
    echo '<span class="logo-icon">🐾</span><span class="logo-text">Pet<b>World</b></span>';
    echo '</a>';
    echo '<nav class="nav">';
    foreach ($navItems as $key => [$url, $label]) {
        $cls = $activo === $key ? ' class="active"' : '';
        echo "<a href=\"$url\"$cls>$label</a>";
    }
    echo '</nav>';
    echo '<div class="nav-actions">';
    echo "<a href=\"favoritos.php\" class=\"nav-icon-btn\" aria-label=\"Favoritos\">";
    echo '♥';
    if ($favCount > 0) echo "<span class=\"badge-count\">$favCount</span>";
    echo '</a>';
    echo "<a href=\"carrito.php\" class=\"nav-icon-btn\" aria-label=\"Carrito\">";
    echo '🛒';
    if ($cartCount > 0) echo "<span class=\"badge-count\">$cartCount</span>";
    echo '</a>';
    echo '</div>';
    echo '<button class="nav-toggle" id="nav-toggle" aria-label="Menú">☰</button>';
    echo '</div>';
    echo '</header>';
}
