<?php
/**
 * conexion.php — Conexión PDO a MySQL (XAMPP)
 * Requiere config.php (carga las credenciales desde ahí).
 */
require_once __DIR__ . '/config.php';

$dsn = "mysql:host={$DB_HOST};port={$DB_PUERTO};dbname={$DB_NAME};charset=utf8mb4";

$opciones = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_PERSISTENT         => false,
];

try {
    $conexion = new PDO($dsn, $DB_USER, $DB_PASSWORD, $opciones);
} catch (PDOException $e) {
    http_response_code(500);
    $msg  = '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">';
    $msg .= '<title>Error de conexión · PetWorld</title>';
    $msg .= '<style>body{font-family:Segoe UI,Arial;background:#FFF8F0;color:#2A1F14;padding:40px;}';
    $msg .= '.card{max-width:680px;margin:auto;background:#fff;border-radius:12px;padding:30px;border-left:6px solid #FF7A00;box-shadow:0 4px 12px rgba(0,0,0,.05);}';
    $msg .= 'h1{color:#FF7A00;margin-top:0;}code{background:#f4f4f4;padding:2px 6px;border-radius:4px;}';
    $msg .= 'ol{line-height:1.7;}</style></head><body><div class="card">';
    $msg .= '<h1>⚠ No se pudo conectar con MySQL (XAMPP)</h1>';
    $msg .= '<p><b>Error PDO:</b> <code>' . htmlspecialchars($e->getMessage()) . '</code></p>';
    $msg .= '<p>Revisa paso a paso:</p><ol>';
    $msg .= '<li>Panel de Control de <b>XAMPP</b>: <b>Apache</b> y <b>MySQL</b> en verde.</li>';
    $msg .= '<li>Entra a <a href="http://localhost/phpmyadmin" target="_blank">phpMyAdmin</a> y confirma que exista la BD <code>petworld</code>.</li>';
    $msg .= '<li>Si NO existe, importa <code>database/petworld.sql</code> desde phpMyAdmin (Importar).</li>';
    $msg .= '<li>Confirma que el puerto <code>3306</code> esté libre (sin otro MySQL corriendo).</li>';
    $msg .= '<li>Revisa <code>config.php</code>: usuario=<code>root</code>, contraseña vacía.</li>';
    $msg .= '</ol><p>Archivo: <code>conexion.php</code></p></div></body></html>';
    die($msg);
}
