<?php
/** admin/pedidos.php — Gestión de pedidos (actualizar estados) */
require_once __DIR__ . '/auth.php';

// Actualizar estado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pedido_id'])) {
    $id      = (int)$_POST['pedido_id'];
    $pago    = $_POST['estado_pago']   ?? 'Pendiente';
    $envio   = $_POST['estado_envio']  ?? 'Procesando';
    try {
        $stmt = $conexion->prepare("UPDATE pedidos SET estado_pago=?, estado_envio=? WHERE id=?");
        $stmt->execute([$pago, $envio, $id]);
        $msg = "Pedido #$id actualizado.";
    } catch (PDOException $e) { $err = "Error: " . $e->getMessage(); }
}

// Filtro
$filtro = $_GET['estado'] ?? '';
$sql = "SELECT * FROM pedidos";
$params = [];
if (in_array($filtro, ['Procesando','En tránsito','Entregado','Cancelado'], true)) {
    $sql .= " WHERE estado_envio = ?";
    $params[] = $filtro;
}
$sql .= " ORDER BY fecha DESC";
$stmt = $conexion->prepare($sql);
$stmt->execute($params);
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pedidos · Admin PetWorld</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div class="admin-layout">
  <aside class="admin-side">
    <div class="brand">🐾 PetWorld</div>
    <a href="index.php">📊 Dashboard</a>
    <a href="productos.php">📦 Productos</a>
    <a href="pedidos.php" class="active">🧾 Pedidos</a>
    <a href="../index.php" target="_blank">🛍 Ver tienda</a>
    <a href="logout.php" style="color:#ff8888;">⏻ Cerrar sesión</a>
  </aside>
  <main class="admin-main">
    <h1>🧾 Pedidos</h1>
    <?php if (!empty($msg)): ?><div class="alert alert-ok">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <?php if (!empty($err)): ?><div class="alert alert-err">✗ <?= htmlspecialchars($err) ?></div><?php endif; ?>

    <div style="margin-bottom:16px;">
      Filtrar:
      <a href="pedidos.php" class="btn btn-ghost btn-sm">Todos</a>
      <a href="pedidos.php?estado=Procesando" class="btn btn-ghost btn-sm">Procesando</a>
      <a href="pedidos.php?estado=En tránsito" class="btn btn-ghost btn-sm">En tránsito</a>
      <a href="pedidos.php?estado=Entregado" class="btn btn-ghost btn-sm">Entregado</a>
    </div>

    <div class="admin-card">
      <?php if (empty($pedidos)): ?>
        <div class="empty-state"><div class="ic">📭</div><h3>No hay pedidos</h3></div>
      <?php else: ?>
      <table class="table">
        <thead><tr>
          <th>Código</th><th>Cliente</th><th>Contacto</th><th>Total</th>
          <th>Método</th><th>Pago</th><th>Envío</th><th>Fecha</th><th>Actualizar</th>
        </tr></thead>
        <tbody>
          <?php foreach ($pedidos as $p): ?>
          <tr>
            <td><b><?= htmlspecialchars($p['codigo_seguimiento']) ?></b></td>
            <td><?= htmlspecialchars($p['cliente_nombre']) ?><br><small style="color:var(--pw-gray)"><?= htmlspecialchars($p['direccion_envio']) ?></small></td>
            <td><small><?= htmlspecialchars($p['cliente_email']) ?><br><?= htmlspecialchars($p['cliente_telefono'] ?: '') ?></small></td>
            <td><b>$<?= number_format($p['total'], 2) ?></b></td>
            <td><?= htmlspecialchars($p['metodo_pago']) ?></td>
            <td>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="pedido_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="estado_envio" value="<?= htmlspecialchars($p['estado_envio']) ?>">
                <select name="estado_pago" onchange="this.form.submit()">
                  <?php foreach (['Pendiente','Pagado','Cancelado'] as $s): ?>
                    <option <?= $p['estado_pago']===$s?'selected':'' ?>><?= $s ?></option>
                  <?php endforeach; ?>
                </select>
              </form>
            </td>
            <td>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="pedido_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="estado_pago" value="<?= htmlspecialchars($p['estado_pago']) ?>">
                <select name="estado_envio" onchange="this.form.submit()">
                  <?php foreach (['Procesando','En tránsito','Entregado','Cancelado'] as $s): ?>
                    <option <?= $p['estado_envio']===$s?'selected':'' ?>><?= $s ?></option>
                  <?php endforeach; ?>
                </select>
              </form>
            </td>
            <td><small><?= date('d/m/Y H:i', strtotime($p['fecha'])) ?></small></td>
            <td><a href="../seguimiento.php?codigo=<?= urlencode($p['codigo_seguimiento']) ?>" target="_blank" class="btn btn-ghost btn-sm">Ver</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>
