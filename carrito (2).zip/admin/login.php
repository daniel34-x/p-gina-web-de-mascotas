<?php
/** admin/login.php — Acceso al panel admin */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: index.php'); exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    try {
        $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE email = ? AND rol='admin' LIMIT 1");
        $stmt->execute([$email]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($u && password_verify($pass, $u['password'])) {
            $_SESSION['admin_id'] = (int)$u['id'];
            header('Location: index.php'); exit;
        } else {
            $error = 'Correo o contraseña incorrectos.';
        }
    } catch (PDOException $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Acceso Admin · PetWorld</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div class="admin-login">
  <h1>🐾 PetWorld Admin</h1>
  <?php if ($error): ?><div class="alert alert-err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST" action="login.php">
    <div class="field" style="margin-bottom:14px;">
      <label>Correo</label>
      <input type="email" name="email" required value="admin@petworld.mx" style="width:100%;padding:11px;border:1.5px solid var(--pw-line);border-radius:8px;">
    </div>
    <div class="field" style="margin-bottom:18px;">
      <label>Contraseña</label>
      <input type="password" name="password" required placeholder="admin123" style="width:100%;padding:11px;border:1.5px solid var(--pw-line);border-radius:8px;">
    </div>
    <button type="submit" class="btn btn-primary btn-block btn-lg">Ingresar →</button>
  </form>
  <p style="text-align:center;margin-top:18px;font-size:12px;color:var(--pw-gray);">
    Demo: <code>admin@petworld.mx</code> / <code>admin123</code><br>
    <a href="../index.php">← Volver a la tienda</a>
  </p>
</div>
</body>
</html>
