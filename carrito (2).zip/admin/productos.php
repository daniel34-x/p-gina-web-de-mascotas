<?php
/** admin/productos.php — CRUD de productos */
require_once __DIR__ . '/auth.php';

// Cargar categorías para el select
$cats = $conexion->query("SELECT * FROM categorias ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);

// ---------- Acciones ----------
$editando = null;

// Eliminar
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $conexion->prepare("DELETE FROM productos WHERE id = ?")->execute([$id]);
        $msg = "Producto #$id eliminado.";
    } catch (PDOException $e) { $err = "No se pudo eliminar: " . $e->getMessage(); }
}

// Crear / Actualizar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $nombre     = trim($_POST['nombre'] ?? '');
    $marca      = trim($_POST['marca'] ?? '');
    $categoria  = (int)($_POST['categoria_id'] ?? 0);
    $precio     = (float)($_POST['precio'] ?? 0);
    $precio_ant = $_POST['precio_anterior'] !== '' ? (float)$_POST['precio_anterior'] : null;
    $imagen     = trim($_POST['imagen'] ?? '🐾');
    $etiqueta   = trim($_POST['etiqueta'] ?? '') ?: null;
    $calif      = (float)($_POST['calificacion'] ?? 5);
    $resenas    = (int)($_POST['total_resenas'] ?? 0);
    $destacado  = isset($_POST['destacado']) ? 1 : 0;
    $stock      = (int)($_POST['stock'] ?? 0);
    $desc       = trim($_POST['descripcion'] ?? '');

    if ($nombre === '' || $categoria === 0) {
        $err = "Nombre y categoría son obligatorios.";
    } else {
        try {
            if ($id > 0) {
                $stmt = $conexion->prepare("UPDATE productos SET nombre=?, marca=?, categoria_id=?, precio=?, precio_anterior=?, imagen=?, etiqueta=?, calificacion=?, total_resenas=?, destacado=?, stock=?, descripcion=? WHERE id=?");
                $stmt->execute([$nombre,$marca,$categoria,$precio,$precio_ant,$imagen,$etiqueta,$calif,$resenas,$destacado,$stock,$desc,$id]);
                $msg = "Producto actualizado.";
            } else {
                $stmt = $conexion->prepare("INSERT INTO productos (nombre,marca,categoria_id,precio,precio_anterior,imagen,etiqueta,calificacion,total_resenas,destacado,stock,descripcion) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                $stmt->execute([$nombre,$marca,$categoria,$precio,$precio_ant,$imagen,$etiqueta,$calif,$resenas,$destacado,$stock,$desc]);
                $msg = "Producto creado con ID #" . $conexion->lastInsertId();
            }
        } catch (PDOException $e) { $err = "Error: " . $e->getMessage(); }
    }
}

// Editar: cargar datos
if (isset($_GET['edit'])) {
    $stmt = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editando = $stmt->fetch(PDO::FETCH_ASSOC);
}

// ---------- Listar ----------
$productos = $conexion->query("SELECT p.*, c.nombre AS catLabel FROM productos p INNER JOIN categorias c ON p.categoria_id=c.id ORDER BY p.id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Productos · Admin PetWorld</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div class="admin-layout">
  <aside class="admin-side">
    <div class="brand">🐾 PetWorld</div>
    <a href="index.php">📊 Dashboard</a>
    <a href="productos.php" class="active">📦 Productos</a>
    <a href="pedidos.php">🧾 Pedidos</a>
    <a href="../index.php" target="_blank">🛍 Ver tienda</a>
    <a href="logout.php" style="color:#ff8888;">⏻ Cerrar sesión</a>
  </aside>
  <main class="admin-main">
    <h1>📦 Productos</h1>
    <?php if (!empty($msg)): ?><div class="alert alert-ok">✓ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <?php if (!empty($err)): ?><div class="alert alert-err">✗ <?= htmlspecialchars($err) ?></div><?php endif; ?>

    <div class="admin-card">
      <h2><?= $editando ? "Editar producto #{$editando['id']}" : '➕ Nuevo producto' ?></h2>
      <form method="POST" action="productos.php">
        <input type="hidden" name="id" value="<?= $editando['id'] ?? 0 ?>">
        <div class="form-grid">
          <div class="field full"><label>Nombre *</label><input type="text" name="nombre" required value="<?= htmlspecialchars($editando['nombre'] ?? '') ?>"></div>
          <div class="field"><label>Marca</label><input type="text" name="marca" value="<?= htmlspecialchars($editando['marca'] ?? '') ?>"></div>
          <div class="field"><label>Categoría *</label>
            <select name="categoria_id" required>
              <?php foreach ($cats as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= ($editando['categoria_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nombre']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label>Precio *</label><input type="number" step="0.01" name="precio" required value="<?= htmlspecialchars($editando['precio'] ?? '') ?>"></div>
          <div class="field"><label>Precio anterior</label><input type="number" step="0.01" name="precio_anterior" value="<?= htmlspecialchars($editando['precio_anterior'] ?? '') ?>"></div>
          <div class="field"><label>Imagen (emoji o URL)</label><input type="text" name="imagen" value="<?= htmlspecialchars($editando['imagen'] ?? '🐾') ?>"></div>
          <div class="field"><label>Etiqueta</label><input type="text" name="etiqueta" placeholder="-20% / Nuevo / vacío" value="<?= htmlspecialchars($editando['etiqueta'] ?? '') ?>"></div>
          <div class="field"><label>Calificación (0-5)</label><input type="number" step="0.1" min="0" max="5" name="calificacion" value="<?= htmlspecialchars($editando['calificacion'] ?? '5.0') ?>"></div>
          <div class="field"><label>Total reseñas</label><input type="number" name="total_resenas" value="<?= htmlspecialchars($editando['total_resenas'] ?? '0') ?>"></div>
          <div class="field"><label>Stock</label><input type="number" name="stock" value="<?= htmlspecialchars($editando['stock'] ?? '0') ?>"></div>
          <div class="field" style="display:flex;align-items:center;gap:8px;padding-top:24px;">
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;">
              <input type="checkbox" name="destacado" <?= !empty($editando['destacado']) ? 'checked' : '' ?>> Destacado
            </label>
          </div>
          <div class="field full"><label>Descripción</label><textarea name="descripcion" rows="2"><?= htmlspecialchars($editando['descripcion'] ?? '') ?></textarea></div>
        </div>
        <div style="margin-top:14px;display:flex;gap:10px;">
          <button type="submit" class="btn btn-primary"><?= $editando ? 'Guardar cambios' : 'Crear producto' ?></button>
          <?php if ($editando): ?><a href="productos.php" class="btn btn-ghost">Cancelar</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="admin-card">
      <h2>Lista de productos (<?= count($productos) ?>)</h2>
      <table class="table">
        <thead><tr><th>ID</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Dest.</th><th>Acciones</th></tr></thead>
        <tbody>
          <?php foreach ($productos as $p): ?>
          <tr>
            <td><?= (int)$p['id'] ?></td>
            <td><b><?= htmlspecialchars($p['nombre']) ?></b><br><small><?= htmlspecialchars($p['marca'] ?? '') ?></small></td>
            <td><?= htmlspecialchars($p['catLabel']) ?></td>
            <td>$<?= number_format($p['precio'], 2) ?></td>
            <td><?= (int)$p['stock'] ?></td>
            <td><?= $p['destacado'] ? '⭐' : '—' ?></td>
            <td>
              <a href="productos.php?edit=<?= (int)$p['id'] ?>" class="btn btn-ghost btn-sm">Editar</a>
              <a href="productos.php?delete=<?= (int)$p['id'] ?>" class="btn btn-ghost btn-sm" style="color:var(--pw-red);" onclick="return confirm('¿Eliminar este producto?')">Eliminar</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
