<?php
/** admin/index.php — Dashboard */
require_once __DIR__ . '/auth.php';

// KPIs
$totalProductos = (int)$conexion->query("SELECT COUNT(*) FROM productos")->fetchColumn();
$totalPedidos   = (int)$conexion->query("SELECT COUNT(*) FROM pedidos")->fetchColumn();
$ingresos       = (float)$conexion->query("SELECT COALESCE(SUM(total),0) FROM pedidos WHERE estado_pago='Pagado'")->fetchColumn();
$pendientes     = (int)$conexion->query("SELECT COUNT(*) FROM pedidos WHERE estado_pago='Pendiente'")->fetchColumn();

$recientes = $conexion->query("SELECT * FROM pedidos ORDER BY fecha DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard · Admin PetWorld</title>
<link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<div class="admin-layout">
  <aside class="admin-side">
    <div class="brand">🐾 PetWorld</div>
    <a href="index.php" class="active">📊 Dashboard</a>
    <a href="productos.php">📦 Productos</a>
    <a href="pedidos.php">🧾 Pedidos</a>
    <a href="../index.php" target="_blank">🛍 Ver tienda</a>
    <a href="logout.php" style="color:#ff8888;">⏻ Cerrar sesión</a>
  </aside>
  <main class="admin-main">
    <h1>Dashboard</h1>
    <p style="color:var(--pw-gray);margin-bottom:20px;">Bienvenido, <b><?= htmlspecialchars($adminActual['nombre']) ?></b></p>

    <div class="kpi-grid">
      <div class="kpi"><div class="ic">📦</div><div class="v"><?= $totalProductos ?></div><div class="l">Productos</div></div>
      <div class="kpi"><div class="ic">🧾</div><div class="v"><?= $totalPedidos ?></div><div class="l">Pedidos totales</div></div>
      <div class="kpi"><div class="ic">💰</div><div class="v">$<?= number_format($ingresos, 0) ?></div><div class="l">Ingresos (pagados)</div></div>
      <div class="kpi"><div class="ic">⏳</div><div class="v"><?= $pendientes ?></div><div class="l">Pagos pendientes</div></div>
    </div>

    <div class="admin-card">
      <h2>🧾 Pedidos recientes</h2>
      <?php if (!empty($recientes)): ?>
      <table class="table">
        <thead><tr><th>Código</th><th>Cliente</th><th>Total</th><th>Pago</th><th>Envío</th><th>Fecha</th></tr></thead>
        <tbody>
          <?php foreach ($recientes as $p): ?>
          <tr>
            <td><b><?= htmlspecialchars($p['codigo_seguimiento']) ?></b></td>
            <td><?= htmlspecialchars($p['cliente_nombre']) ?></td>
            <td>$<?= number_format($p['total'], 2) ?></td>
            <td><span class="pill <?= $p['estado_pago']==='Pagado'?'pill-green':'pill-yellow' ?>"><?= htmlspecialchars($p['estado_pago']) ?></span></td>
            <td><span class="pill <?= $p['estado_envio']==='Entregado'?'pill-green':($p['estado_envio']==='En tránsito'?'pill-blue':'pill-yellow') ?>"><?= htmlspecialchars($p['estado_envio']) ?></span></td>
            <td><?= date('d/m/Y H:i', strtotime($p['fecha'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <p style="margin-top:12px;"><a href="pedidos.php" class="btn btn-ghost btn-sm">Ver todos los pedidos →</a></p>
      <?php else: ?>
        <div class="empty-state"><div class="ic">📭</div><h3>Aún no hay pedidos</h3></div>
      <?php endif; ?>
    </div>
  </main>
</div>
</body>
</html>
