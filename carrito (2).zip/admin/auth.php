<?php
/** admin/auth.php — Verifica sesión admin. Incluir al inicio de cada página protegida. */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../conexion.php';

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Cargar datos del admin actual
$stmt = $conexion->prepare("SELECT * FROM usuarios WHERE id = ? AND rol='admin' LIMIT 1");
$stmt->execute([$_SESSION['admin_id']]);
$adminActual = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$adminActual) {
    session_destroy();
    header('Location: login.php');
    exit;
}
